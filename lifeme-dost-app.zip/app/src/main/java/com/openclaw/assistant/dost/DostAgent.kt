package com.openclaw.assistant.dost

import android.content.Context
import com.google.adk.firebase.models.Firebase as AdkFirebase
import com.google.adk.kt.agents.Instruction
import com.google.adk.kt.agents.LlmAgent
import com.google.adk.kt.agents.RunConfig
import com.google.adk.kt.agents.StreamingMode
import com.google.adk.kt.models.Model
import com.google.adk.kt.models.openai.ChatCompletions
import com.google.adk.kt.runners.InMemoryRunner
import com.google.adk.kt.sessions.InMemorySessionService
import com.google.adk.kt.types.Content
import com.google.adk.kt.types.HttpOptions
import com.google.adk.kt.types.Part
import com.google.adk.kt.types.Role
import com.google.firebase.FirebaseApp
import com.google.firebase.ai.FirebaseAI

/**
 * The in-app agent engine (Google ADK for Kotlin).
 *
 * Model selection (zero cost, single user):
 *  1. Firebase AI Logic free tier — when the user enables it in Dost Settings
 *     (needs a real google-services.json in the build; falls through otherwise).
 *  2. BYOK Gemini API key via Gemini's OpenAI-compatible endpoint (default).
 *
 * Tools: DostDeviceTools (KSP-generated @Tool wrappers) — the automation layer.
 */
object DostAgent {

    const val AGENT_NAME = "dost"
    private const val APP_NAME = "lifeme-dost"
    private const val USER_ID = "aadesh"
    private const val SESSION_ID = "main"
    private const val HEARTBEAT_SESSION = "heartbeat"

    private val sessionService = InMemorySessionService()

    @Volatile
    private var cachedRunner: InMemoryRunner? = null
    @Volatile
    private var cachedKey: String? = null

    fun getModelMode(ctx: Context): String =
        ctx.getSharedPreferences("dost_plain", Context.MODE_PRIVATE)
            .getString("model_mode", "byok") ?: "byok"

    fun setModelMode(ctx: Context, mode: String) {
        ctx.getSharedPreferences("dost_plain", Context.MODE_PRIVATE)
            .edit().putString("model_mode", mode).apply()
        invalidate()
    }

    private fun buildModel(context: Context): Model? {
        // 1. Firebase AI Logic (free tier), opt-in.
        if (getModelMode(context) == "firebase") {
            try {
                val app = FirebaseApp.getApps(context).firstOrNull()
                    ?: FirebaseApp.initializeApp(context)
                if (app != null) {
                    return AdkFirebase.create(
                        DostPersona.MODEL_NAME,
                        FirebaseAI.getInstance(app)
                    )
                }
            } catch (_: Exception) {
                // fall through to BYOK
            }
        }
        // 2. BYOK Gemini key via OpenAI-compatible endpoint.
        val key = DostSecurePrefs.getApiKey(context)
        if (key.isBlank()) return null
        return ChatCompletions(
            name = DostPersona.MODEL_NAME,
            apiKey = key,
            httpOptions = HttpOptions(baseUrl = DostPersona.OPENAI_BASE_URL)
        )
    }

    private fun getRunner(context: Context): InMemoryRunner {
        val model = buildModel(context)
            ?: throw IllegalStateException("Dost ke liye API key chahiye (Settings me daalo)")
        val mode = getModelMode(context)
        val keyHash = DostSecurePrefs.getApiKey(context).hashCode()
        val facts = DostMemory.db(context).dao().topFacts(10)
        val persona = DostPersonas.current(context)
        val cacheKey = "$mode|$keyHash|${facts.size}|${facts.sumOf { it.id }}|${persona.id}"
        val existing = cachedRunner
        if (existing != null && cachedKey == cacheKey) return existing
        val agent = LlmAgent(
            name = AGENT_NAME,
            model = model,
            instruction = Instruction(DostPersona.systemPrompt(facts, persona)),
            tools = DostDeviceTools(context.applicationContext).generatedTools() +
                DostWebTools(context.applicationContext).generatedTools() +
                DostVisionTools(context.applicationContext).generatedTools() +
                DostReminderTools(context.applicationContext).generatedTools() +
                DostPlanTools(context.applicationContext).generatedTools() +
                DostImageTools(context.applicationContext).generatedTools()
        )
        return InMemoryRunner(
            agent = agent,
            appName = APP_NAME,
            sessionService = sessionService
        ).also { cachedRunner = it; cachedKey = cacheKey }
    }

    fun invalidate() {
        cachedRunner = null
        cachedKey = null
    }

    private suspend fun runTurn(
        runner: InMemoryRunner,
        sessionId: String,
        text: String
    ): String {
        val sb = StringBuilder()
        runner.runAsync(
            userId = USER_ID,
            sessionId = sessionId,
            newMessage = Content(role = Role.USER, parts = listOf(Part(text = text))),
            runConfig = RunConfig(streamingMode = StreamingMode.NONE),
        ).collect { event ->
            if (event.author != AGENT_NAME) return@collect
            event.errorMessage?.let { throw RuntimeException(it) }
            val chunk = event.content?.parts.orEmpty()
                .filter { it.thought != true }
                .mapNotNull { it.text }
                .joinToString("").trim()
            if (chunk.isNotBlank()) {
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append(chunk)
            }
        }
        return sb.toString().trim()
    }

    /** One chat turn. Returns reply text. Throws on failure (caller falls back). */
    suspend fun chat(context: Context, text: String): String =
        runTurn(getRunner(context), SESSION_ID, withRecall(context, text))

    /** Semantic recall: related memories are prepended (agent-only, never stored). */
    private fun withRecall(context: Context, text: String): String {
        return try {
            val recalled = DostSemanticMemory.recall(context, text, 3)
            if (recalled.isEmpty()) text
            else "Related yaadein (inhe dhyaan me rakho):\n" +
                recalled.joinToString("\n") { "- $it" } + "\n\nUser: $text"
        } catch (_: Exception) {
            text
        }
    }

    /**
     * One chat turn with SSE streaming (ADK example pattern: partial deltas grow
     * the bubble, a non-partial event ends the segment).
     *
     * [onText] is called with the FULL reply text so far each time new tokens
     * arrive — the UI just renders the latest string. Returns the final reply.
     * Throws on failure (caller falls back).
     */
    suspend fun chatStream(
        context: Context,
        text: String,
        onText: (String) -> Unit
    ): String {
        val runner = getRunner(context)
        val sb = StringBuilder()
        var streamed = false // partials seen since the last segment-ending event
        runner.runAsync(
            userId = USER_ID,
            sessionId = SESSION_ID,
            newMessage = Content(role = Role.USER, parts = listOf(Part(text = withRecall(context, text)))),
            runConfig = RunConfig(streamingMode = StreamingMode.SSE),
        ).collect { event ->
            if (event.author != AGENT_NAME) return@collect
            event.errorMessage?.let { throw RuntimeException(it) }
            val chunk = event.content?.parts.orEmpty()
                .filter { it.thought != true }
                .mapNotNull { it.text }
                .joinToString("")
            if (event.partial) {
                if (chunk.isNotEmpty()) {
                    sb.append(chunk)
                    streamed = true
                    onText(sb.toString())
                }
            } else if (chunk.isNotBlank()) {
                if (!streamed) {
                    // No partials for this segment: the final event IS the text.
                    if (sb.isNotEmpty()) sb.append("\n")
                    sb.append(chunk.trim())
                }
                // Otherwise the final event just repeats the streamed partials.
                streamed = false
                onText(sb.toString())
            }
        }
        return sb.toString().trim()
    }

    /**
     * Cheap heartbeat turn (separate session, full persona but no memory writes).
     * Used by the proactive check-in scheduler.
     */
    suspend fun heartbeatTurn(context: Context, prompt: String): String? {
        return try {
            runTurn(getRunner(context), HEARTBEAT_SESSION, prompt).ifEmpty { null }
        } catch (_: Exception) {
            null
        }
    }
}

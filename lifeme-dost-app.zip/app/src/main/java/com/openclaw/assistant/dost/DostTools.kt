package com.openclaw.assistant.dost

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.CalendarContract
import com.google.adk.kt.annotations.Param
import com.google.adk.kt.annotations.Tool
import com.openclaw.assistant.service.OpenClawNotificationListenerService
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

/**
 * The automation layer: phone capabilities wrapped as ADK @Tool functions.
 * KSP generates a FunctionTool wrapper per function (see DostAgent).
 *
 * PRIVACY: no SMS/OTP reading exists anywhere here. Notification reading
 * drops finance-app packages via DostPrivacy before the agent sees anything.
 * remember_fact refuses financial facts.
 */
class DostDeviceTools(private val appContext: Context) {

    /** Phone ki basic jaankari: model aur Android version. */
    @Tool
    fun getDeviceInfo(): String {
        return "manufacturer=${Build.MANUFACTURER}, model=${Build.MODEL}, " +
            "android=${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
    }

    /** Install kiye gaye launchable apps ki list (pehle 40). */
    @Tool
    fun listApps(): String {
        return try {
            val pm = appContext.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val infos = pm.queryIntentActivities(intent, 0)
            infos.take(40).joinToString("\n") { ri ->
                val label = runCatching { ri.loadLabel(pm).toString() }.getOrNull()
                    ?: ri.activityInfo.packageName
                "$label (${ri.activityInfo.packageName})"
            }.ifEmpty { "koi app nahi mili" }
        } catch (e: Exception) {
            "apps list nahi padh paya: ${e.message}"
        }
    }

    /** Kisi app ko package name se kholo. Sensitive action: pehle confirm hota hai. */
    @Tool
    fun launchApp(
        @Param("App ka package name, jaise com.spotify.music") packageName: String,
        @Param("user ne confirm kiya ho to true, warna false") confirmed: Boolean = false,
        @Param("sirf preview dikhana ho (execute nahi karna) to true") dryRun: Boolean = false
    ): String {
        DostConfirm.gate(
            appContext, "launch_app",
            "app kholna: $packageName", confirmed, dryRun
        )?.let { return it }
        return try {
            val intent = appContext.packageManager.getLaunchIntentForPackage(packageName)
                ?: return "yeh app nahi mili ya khul nahi sakti: $packageName"
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
            DostPlan.logUndo(appContext, "launch_app:$packageName", "app band karna (haath se)")
            "app khol di: $packageName"
        } catch (e: Exception) {
            "app nahi khol paya: ${e.message}"
        }
    }

    /** Clipboard ka current text padho. */
    @Tool
    fun readClipboard(): String {
        return try {
            val cm = appContext.getSystemService(Context.CLIPBOARD_SERVICE)
                as android.content.ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(appContext)?.toString()
                ?.takeIf { it.isNotBlank() }
                ?: "clipboard khaali hai"
        } catch (e: Exception) {
            "clipboard nahi padh paya: ${e.message}"
        }
    }

    /**
     * Active system notifications padho (notification access on hone par).
     * PRIVACY: finance/banking apps ki notifications pehle hi drop ho chuki
     * hain (DostPrivacy) — agent unhe kabhi nahi dekhta.
     */
    @Tool
    fun readNotifications(): String {
        return try {
            val snap = DostPrivacy.filterBlocked(
                appContext,
                OpenClawNotificationListenerService.activeSnapshot()
            )
            if (snap.isEmpty()) return "koi active notification nahi hai (ya notification access off hai)"
            snap.take(15).joinToString("\n---\n") { sbn ->
                val extras = sbn.notification?.extras
                val title = extras?.getCharSequence("android.title")?.toString() ?: ""
                val text = extras?.getCharSequence("android.text")?.toString() ?: ""
                "[${sbn.packageName}] $title — ${text.take(200)}"
            }
        } catch (e: Exception) {
            "notifications nahi padh paya: ${e.message}"
        }
    }

    /** WiFi connection ka status. */
    @Tool
    fun getWifiStatus(): String {
        return try {
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val info = wm.connectionInfo
            "connected=${wm.isWifiEnabled}, ssid=${info?.ssid ?: "unknown"}"
        } catch (e: Exception) {
            "wifi status nahi mil paya: ${e.message}"
        }
    }

    /** Aaj ke calendar events (title + time). */
    @Tool
    fun getTodaysCalendarEvents(): String {
        return try {
            val cr = appContext.contentResolver
            val now = System.currentTimeMillis()
            val startOfDay = now - (now % 86_400_000L)
            val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                .appendPath(startOfDay.toString())
                .appendPath((startOfDay + 86_400_000L).toString())
                .build()
            val cursor = cr.query(
                uri,
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
                null, null,
                "${CalendarContract.Instances.BEGIN} ASC"
            ) ?: return "calendar nahi padh paya"
            val out = StringBuilder()
            cursor.use {
                val ti = it.getColumnIndex(CalendarContract.Instances.TITLE)
                val bi = it.getColumnIndex(CalendarContract.Instances.BEGIN)
                var count = 0
                while (it.moveToNext() && count < 10) {
                    val title = if (ti >= 0) it.getString(ti) ?: "(bina title)" else "(bina title)"
                    val begin = if (bi >= 0) it.getLong(bi) else 0L
                    val time = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                        .format(java.util.Date(begin))
                    out.appendLine("$time — $title")
                    count++
                }
                if (count == 0) out.append("aaj koi event nahi hai")
            }
            out.toString().trim()
        } catch (e: SecurityException) {
            "calendar permission nahi hai"
        } catch (e: Exception) {
            "calendar nahi padh paya: ${e.message}"
        }
    }

    /** Free web search (bina API key ke). */
    @Tool
    fun webSearch(
        @Param("search query") query: String
    ): String {
        return try {
            val url = "https://api.duckduckgo.com/?q=" + URLEncoder.encode(query, "UTF-8") +
                "&format=json&no_html=1&skip_disambig=1"
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15000
                c.readTimeout = 20000
                val resp = c.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(resp)
                val answer = json.optString("AbstractText").ifEmpty { json.optString("Answer") }
                if (answer.isNotBlank()) return answer.take(800)
                val topics = json.optJSONArray("RelatedTopics")
                val sb = StringBuilder()
                if (topics != null) {
                    for (i in 0 until minOf(topics.length(), 3)) {
                        val t = topics.optJSONObject(i)?.optString("Text") ?: continue
                        if (t.isNotBlank()) sb.appendLine("- ${t.take(200)}")
                    }
                }
                sb.toString().trim().ifEmpty { "kuch khaas nahi mila: $query" }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            "search fail: ${e.message}"
        }
    }

    /** Reminder lagao — exact alarm, notification aayega. Pehle confirm hota hai. */
    @Tool
    fun setReminder(
        @Param("kitne minute baad yaad dilana hai") minutes: Int,
        @Param("reminder ka text") text: String,
        @Param("user ne confirm kiya ho to true, warna false") confirmed: Boolean = false,
        @Param("sirf preview dikhana ho (execute nahi karna) to true") dryRun: Boolean = false
    ): String {
        DostConfirm.gate(
            appContext, "set_reminder",
            "reminder: '$text' ($minutes minute baad)", confirmed, dryRun
        )?.let { return it }
        return try {
            DostHeartbeat.scheduleReminder(appContext, minutes.coerceIn(1, 4320), text)
            DostPlan.logUndo(appContext, "reminder:$text", "reminder cancel karna (haath se)")
            "reminder set kar diya: '$text' ($minutes minute baad)"
        } catch (e: Exception) {
            "reminder nahi lag paya: ${e.message}"
        }
    }

    /**
     * aadesh ke baare me koi pakki baat yaad rakho.
     * PRIVACY: finance se related baat kabhi yaad nahi rakhi jaati.
     */
    @Tool
    fun rememberFact(
        @Param("yaad rakhne wali baat") fact: String,
        @Param("importance 0 se 1 tak") importance: Double
    ): String {
        if (DostPrivacy.looksFinancial(fact)) {
            return "yeh baat finance se related hai, isliye maine ise yaad nahi rakha (privacy)."
        }
        return try {
            DostMemory.db(appContext).dao().insertFact(
                DostFact(
                    text = fact.trim(),
                    importance = importance.coerceIn(0.0, 1.0),
                    ts = System.currentTimeMillis()
                )
            )
            DostSemanticMemory.indexFact(
                appContext,
                DostFact(
                    text = fact.trim(),
                    importance = importance.coerceIn(0.0, 1.0),
                    ts = System.currentTimeMillis()
                )
            )
            "yaad rakh liya: $fact"
        } catch (e: Exception) {
            "yaad nahi rakh paya: ${e.message}"
        }
    }
}

package com.openclaw.assistant.dost

import android.content.Context
import android.graphics.Bitmap
import com.google.adk.kt.annotations.Tool
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * On-device ML Kit vision bundle (free, no quota, no network):
 *  - OCR: Latin + Devanagari (Hindi/Hinglish text in photos, screenshots, notes)
 *  - Image labeling (400+ categories) as a cheap pre-filter
 *  - Face detection (landmarks + smiling/eyes-open probabilities — detection
 *    only, NEVER identification; no face embeddings are stored)
 *  - Barcode / QR scanning
 *
 * Runs only on photos the USER picks — never background-scans the gallery.
 * The analysis text is what the agent sees; the photo itself is not uploaded
 * unless the user explicitly asks Gemini to look at it.
 */
object DostVision {

    /** Last photo analysis, for agent follow-ups ("us photo me kya tha?"). */
    @Volatile
    var lastAnalysis: String? = null
        private set

    /** Downscale so ML Kit stays fast; keeps aspect ratio. */
    fun downscale(src: Bitmap, maxDim: Int = 1024): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= maxDim && h <= maxDim) return src
        val scale = maxDim.toFloat() / maxOf(w, h)
        return Bitmap.createScaledBitmap(src, (w * scale).toInt(), (h * scale).toInt(), true)
    }

    private suspend fun <T> awaitTask(task: com.google.android.gms.tasks.Task<T>): T =
        suspendCancellableCoroutine { cont ->
            task.addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        }

    /**
     * Full analysis of one bitmap. Returns Hinglish summary text.
     * Each detector is best-effort: one failing must not kill the others.
     */
    suspend fun analyze(bitmap: Bitmap): String {
        val img = InputImage.fromBitmap(bitmap, 0)
        val sb = StringBuilder()

        // OCR: Latin first, then Devanagari (both cheap, on-device).
        val ocr = StringBuilder()
        try {
            val latin = awaitTask(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img))
            if (latin.text.isNotBlank()) ocr.append(latin.text.trim())
        } catch (_: Exception) {
        }
        try {
            val dev = awaitTask(
                TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()).process(img)
            )
            if (dev.text.isNotBlank()) {
                if (ocr.isNotEmpty()) ocr.append("\n")
                ocr.append(dev.text.trim())
            }
        } catch (_: Exception) {
        }
        if (ocr.isNotEmpty()) sb.append("Photo me likha hai:\n${ocr.toString().take(1000)}\n")

        // Image labels (top 5 by confidence).
        try {
            val labels = awaitTask(
                ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(img)
            )
            val top = labels.sortedByDescending { it.confidence }.take(5)
            if (top.isNotEmpty()) {
                sb.append("Photo me dikh raha hai: ")
                sb.append(top.joinToString(", ") { "${it.text} (${(it.confidence * 100).toInt()}%)" })
                sb.append("\n")
            }
        } catch (_: Exception) {
        }

        // Barcodes / QR codes.
        try {
            val codes = awaitTask(BarcodeScanning.getClient().process(img))
            if (codes.isNotEmpty()) {
                sb.append("Barcode/QR: ")
                sb.append(codes.joinToString(", ") { it.rawValue ?: it.displayValue ?: "?" })
                sb.append("\n")
            }
        } catch (_: Exception) {
        }

        // Faces: count + smiling probability only (no identification, no storage).
        try {
            val options = FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build()
            val faces = awaitTask(FaceDetection.getClient(options).process(img))
            if (faces.isNotEmpty()) {
                val smiles = faces.mapNotNull { it.smilingProbability }
                val smileTxt = if (smiles.isNotEmpty()) {
                    ", average smile ${(smiles.average() * 100).toInt()}%"
                } else ""
                sb.append("${faces.size} chehra/chehre mile$smileTxt\n")
            }
        } catch (_: Exception) {
        }

        val result = sb.toString().trim()
            .ifEmpty { "is photo se kuch khaas samajh nahi aaya" }
        lastAnalysis = result
        return result
    }
}

/** ADK tools for vision follow-ups (agent-facing). */
class DostVisionTools(private val appContext: Context) {

    @Tool
    fun getLastPhotoAnalysis(): String {
        return DostVision.lastAnalysis
            ?: "abhi koi photo analyse nahi hui hai — pehle chat me photo pick karo"
    }
}

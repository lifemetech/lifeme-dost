package com.openclaw.assistant.dost

import android.content.Context

/**
 * Proactive habit suggestions (all on-device pattern mining, no new model):
 * a weekly aggregation over Room logs the app already generates (chat hours,
 * reminder topics, message keywords) -> top patterns -> ONE Gemini Flash call
 * phrasing them as questions. Rules: max 1 suggestion per briefing, never
 * during quiet hours (the heartbeat already enforces that), never about
 * finance apps, and each suggestion is delivered at most once per week
 * (delivered-hash set resets weekly).
 */
object DostHabits {

    private const val PREFS = "dost_plain"
    private const val KEY_ENABLED = "habits_enabled"
    private const val KEY_DELIVERED_WEEK = "habits_week"
    private const val KEY_DELIVERED = "habits_delivered"

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, on).apply()
    }

    private val STOPWORDS = setOf(
        "aur", "hai", "hain", "ka", "ki", "ke", "me", "mein", "ne", "se", "to", "the",
        "and", "for", "with", "you", "your", "kya", "kab", "kahan", "kaise", "bhi",
        "tha", "thi", "hoga", "karo", "karke", "raha", "rahi", "rahe", "wala", "wali"
    )

    /** Mine top patterns from local logs. Returns human-readable pattern lines. */
    fun minePatterns(ctx: Context): List<String> {
        return try {
            val dao = DostMemory.db(ctx).dao()
            val out = mutableListOf<String>()
            val messages = dao.allMessages()
            if (messages.isNotEmpty()) {
                // Top chat hour.
                val byHour = messages.groupingBy {
                    java.util.Calendar.getInstance().apply { timeInMillis = it.ts }
                        .get(java.util.Calendar.HOUR_OF_DAY)
                }.eachCount()
                val topHour = byHour.maxByOrNull { it.value }
                if (topHour != null && topHour.value >= 5) {
                    out.add("tum aksar ${topHour.key} baje baat karte ho (${topHour.value} messages)")
                }
                // Top user-message keywords.
                val words = messages.filter { it.role == "user" }
                    .flatMap { it.text.lowercase().split(" ", ",", ".", "?", "!", "\n") }
                    .filter { it.length > 3 && it !in STOPWORDS && !DostPrivacy.looksFinancial(it) }
                val topWords = words.groupingBy { it }.eachCount()
                    .entries.sortedByDescending { it.value }.take(3)
                    .filter { it.value >= 3 }
                if (topWords.isNotEmpty()) {
                    out.add("aksar in topics par baat hoti hai: ${topWords.joinToString(", ") { it.key }}")
                }
            }
            val reminders = dao.activeReminders()
            if (reminders.isNotEmpty()) {
                val daily = reminders.count { it.recurrence == "daily" }
                if (daily > 0) out.add("$daily roz ke reminders active hain")
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * One suggestion from the mined patterns (one Gemini Flash call), or null.
     * Delivered at most once per week per pattern-hash.
     */
    fun suggestOnce(ctx: Context): String? {
        if (!isEnabled(ctx)) return null
        val patterns = minePatterns(ctx)
        if (patterns.isEmpty()) return null
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val week = java.util.Calendar.getInstance().get(java.util.Calendar.WEEK_OF_YEAR).toString()
        if (prefs.getString(KEY_DELIVERED_WEEK, "") != week) {
            prefs.edit().putString(KEY_DELIVERED_WEEK, week).putStringSet(KEY_DELIVERED, emptySet()).apply()
        }
        val delivered = prefs.getStringSet(KEY_DELIVERED, emptySet()) ?: emptySet()
        val key = DostSecurePrefs.getApiKey(ctx)
        val suggestion = if (key.isNotBlank()) {
            DostFallback.generateText(
                key,
                "Tum Dost ho. Neeche ke patterns se ek chhota, pyaara suggestion banao — " +
                    "ek sawaal ki tarah, max 20 shabd, Hinglish me. Finance ka zikr mat karo.",
                patterns.joinToString("\n"), 120, 0.7
            )?.trim()
        } else {
            // No key: template suggestion from the first pattern.
            "Dekha maine: ${patterns[0]}. Is hisaab se kuch set kar du?"
        } ?: return null
        val hash = suggestion.hashCode().toString()
        if (delivered.contains(hash)) return null
        prefs.edit().putStringSet(KEY_DELIVERED, delivered + hash).apply()
        return suggestion
    }
}

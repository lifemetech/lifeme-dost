package com.openclaw.assistant.dost

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Fallback brain: direct Gemini 2.5 Flash REST (BYOK key) with Pollinations
 * keyless fallback. Used when the ADK agent path is unavailable, and for the
 * cheap heartbeat "should I message?" checks.
 *
 * PRIVACY: fact extraction skips anything financial (DostPrivacy).
 */
object DostFallback {

    data class ChatResult(
        val text: String,
        val reminderMinutes: Int?,
        val reminderText: String?
    )

    private class RateLimited(msg: String) : IOException(msg)

    /** Raw one-shot generation with a system prompt. Used by heartbeat etc. */
    fun generateText(
        apiKey: String,
        systemText: String,
        prompt: String,
        maxTokens: Int = 300,
        temperature: Double = 0.7
    ): String? {
        return try {
            val body = JSONObject()
                .put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText)))
                )
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject().put("temperature", temperature).put("maxOutputTokens", maxTokens)
                )
            val raw = postJson(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey",
                body.toString()
            )
            extractText(raw)?.trim()
        } catch (_: Exception) {
            null
        }
    }

    fun chat(
        apiKey: String,
        facts: List<DostFact>,
        history: List<DostMessage>,
        userText: String
    ): ChatResult {
        val systemText = chatSystemText(facts)
        val body = buildChatBody(systemText, history, userText)

        val raw = try {
            postJson(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey",
                body.toString()
            )
        } catch (_: Exception) {
            return ChatResult(pollinationsFallback(systemText, history, userText), null, null)
        }
        val text = extractText(raw)
            ?: return ChatResult(pollinationsFallback(systemText, history, userText), null, null)
        return parseReminder(text)
    }

    /**
     * Streaming chat via Gemini's streamGenerateContent SSE endpoint.
     * [onText] gets the FULL reply text so far as tokens arrive (typing-feel).
     * On any transport failure, falls back to one-shot Pollinations (emitted once).
     */
    fun chatStream(
        apiKey: String,
        facts: List<DostFact>,
        history: List<DostMessage>,
        userText: String,
        onText: (String) -> Unit
    ): ChatResult {
        val systemText = chatSystemText(facts)
        val body = buildChatBody(systemText, history, userText)
        val sb = StringBuilder()
        try {
            val c = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-2.5-flash:streamGenerateContent?alt=sse&key=$apiKey"
            ).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 25000
                c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                c.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body.toString()) }
                val code = c.responseCode
                if (code == 429) throw RateLimited("429 rate limited")
                if (code !in 200..299) throw IOException("HTTP $code")
                c.inputStream.bufferedReader().use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val t = line!!.trim()
                        if (!t.startsWith("data:")) continue
                        val payload = t.removePrefix("data:").trim()
                        if (payload.isEmpty() || payload == "[DONE]") continue
                        val chunk = extractStreamChunk(payload) ?: continue
                        if (chunk.isNotEmpty()) {
                            sb.append(chunk)
                            onText(sb.toString())
                        }
                    }
                }
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            val text = pollinationsFallback(systemText, history, userText)
            onText(text)
            return ChatResult(text, null, null)
        }
        val full = sb.toString().trim()
        if (full.isEmpty()) throw IOException("empty stream")
        return parseReminder(full)
    }

    /**
     * Extract durable facts. PRIVACY: financial-looking facts are dropped —
     * never memorized.
     */
    fun extractFacts(apiKey: String, history: List<DostMessage>): List<DostFact> {
        return try {
            val convo = history.joinToString("\n") {
                (if (it.role == "user") "aadesh" else "Dost") + ": " + it.text
            }
            val prompt = "Is conversation se aadesh ke baare me DURABLE facts nikalo " +
                "(naam, pasand-naapasand, aadatein, goals, important events). " +
                "Banking/finance/paisa se related kuch mat nikalna. " +
                "Sirf JSON array me jawab do, jaise [{\"text\":\"...\",\"importance\":0.9}]. " +
                "importance 0 se 1 tak. Kuch durable na ho to [].\n\nConversation:\n$convo"
            val text = generateText(
                apiKey,
                "Tum ek fact-extraction helper ho. Sirf JSON array me jawab do.",
                prompt, 300, 0.2
            ) ?: return emptyList()
            val start = text.indexOf('[')
            val end = text.lastIndexOf(']')
            if (start < 0 || end <= start) return emptyList()
            val arr = JSONArray(text.substring(start, end + 1))
            val now = System.currentTimeMillis()
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val t = o.optString("text", "").trim()
                val imp = o.optDouble("importance", 0.0)
                // PRIVACY: never memorize financial facts.
                if (t.isEmpty() || DostPrivacy.looksFinancial(t)) return@mapNotNull null
                DostFact(text = t, importance = imp, ts = now)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // ---------- internals ----------

    private fun chatSystemText(facts: List<DostFact>): String {
        val factBlock = if (facts.isEmpty()) "" else
            "\naadesh ke baare me yaad rakho:\n" + facts.joinToString("\n") { "- ${it.text}" }
        return DostPersona.CORE_PROMPT + factBlock
    }

    private fun buildChatBody(
        systemText: String,
        history: List<DostMessage>,
        userText: String
    ): JSONObject {
        val contents = JSONArray()
        for (m in history.takeLast(12)) {
            contents.put(
                JSONObject()
                    .put("role", if (m.role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))
        )
        return JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText)))
            )
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0.9).put("maxOutputTokens", 512)
            )
    }

    /** Text deltas from one SSE data: payload of streamGenerateContent. */
    private fun extractStreamChunk(payload: String): String? {
        return try {
            val parts = JSONObject(payload)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
            (0 until parts.length())
                .mapNotNull { parts.getJSONObject(it).optString("text", null) }
                .joinToString("")
        } catch (_: Exception) {
            null
        }
    }

    private fun parseReminder(text: String): ChatResult {
        val regex = Regex("""<<REMIND:(\d+):(.+?)>>""")
        val match = regex.find(text) ?: return ChatResult(text.trim(), null, null)
        val minutes = match.groupValues[1].toIntOrNull()
        val rtext = match.groupValues[2].trim()
        val cleaned = regex.replace(text, "").trim()
        return ChatResult(cleaned, minutes, rtext.ifEmpty { null })
    }

    private fun extractText(raw: String): String? {
        return try {
            JSONObject(raw)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } catch (_: Exception) {
            null
        }
    }

    @Throws(IOException::class)
    private fun postJson(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 25000
            c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            c.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
            val code = c.responseCode
            if (code == 429) throw RateLimited("429 rate limited")
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val resp = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IOException("HTTP $code")
            return resp
        } finally {
            c.disconnect()
        }
    }

    private fun pollinationsFallback(
        systemText: String,
        history: List<DostMessage>,
        userText: String
    ): String {
        return try {
            val convo = history.takeLast(8).joinToString("\n") {
                (if (it.role == "user") "aadesh" else "Dost") + ": " + it.text
            }
            val prompt = "$systemText\n\nConversation:\n$convo\naadesh: $userText\nDost:"
            val url = "https://text.pollinations.ai/" + URLEncoder.encode(prompt, "UTF-8")
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 25000
                c.readTimeout = 60000
                val code = c.responseCode
                val resp = c.inputStream.bufferedReader().use { it.readText() }.trim()
                if (code in 200..299 && resp.isNotEmpty()) resp
                else "arey, network me kuch gadbad hai dost, thodi der me try kar."
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            "arey, network me kuch gadbad hai dost, thodi der me try kar."
        }
    }
}

package com.openclaw.assistant.dost

import android.content.Context
import com.google.adk.kt.annotations.Param
import com.google.adk.kt.annotations.Tool
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParserFactory

/**
 * Free web-knowledge tools (no API key, no account):
 *  - Open-Meteo weather + geocoding (non-commercial free use, ~10k calls/day
 *    reported fair use, no SLA).
 *  - Google News RSS + outlet RSS (no key, no quota — headlines + snippets).
 *  - DuckDuckGo instant answers already live in DostDeviceTools.webSearch.
 *
 * PRIVACY: results are public web data. Finance-app data never flows here;
 * finance keywords in a query are answered with headlines only, never with
 * personal finance data (the app holds none).
 */
class DostWebTools(private val appContext: Context) {

    /** WMO weather code -> short Hinglish description. */
    private fun weatherText(code: Int): String = when (code) {
        0 -> "saaf aasmaan"
        1, 2 -> "halke baadal"
        3 -> "poora baadal"
        45, 48 -> "kohra"
        51, 53, 55 -> "halki boondabandi"
        61, 63, 65 -> "baarish"
        66, 67 -> "jamne wali baarish"
        71, 73, 75, 77 -> "barf"
        80, 81, 82 -> "tez baarish"
        85, 86 -> "barf ki bochhar"
        95 -> "toofan (bijli ke saath)"
        96, 99 -> "toofan + ole"
        else -> "pata nahi"
    }

    private fun httpGet(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                if (c.responseCode !in 200..299) return null
                c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Kisi sheher ka aaj + kal ka mausam (Open-Meteo, bina key ke). */
    @Tool
    fun getWeather(
        @Param("sheher ka naam, jaise Delhi ya Mumbai") city: String
    ): String {
        return try {
            val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                URLEncoder.encode(city, "UTF-8") + "&count=1&language=en&format=json"
            val geo = httpGet(geoUrl) ?: return "mausam nahi mil paya (network issue)"
            val results = JSONObject(geo).optJSONArray("results")
                ?: return "yeh sheher nahi mila: $city"
            if (results.length() == 0) return "yeh sheher nahi mila: $city"
            val first = results.getJSONObject(0)
            val lat = first.getDouble("latitude")
            val lon = first.getDouble("longitude")
            val name = first.optString("name", city)
            val fcUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=2"
            val fc = httpGet(fcUrl) ?: return "mausam forecast nahi mil paya"
            val root = JSONObject(fc)
            val cur = root.getJSONObject("current")
            val temp = cur.optDouble("temperature_2m", Double.NaN)
            val hum = cur.optDouble("relative_humidity_2m", Double.NaN)
            val wind = cur.optDouble("wind_speed_10m", Double.NaN)
            val code = cur.optInt("weather_code", -1)
            val daily = root.optJSONObject("daily")
            val tMax = daily?.optJSONArray("temperature_2m_max")?.optDouble(0, Double.NaN) ?: Double.NaN
            val tMin = daily?.optJSONArray("temperature_2m_min")?.optDouble(0, Double.NaN) ?: Double.NaN
            val rainProb = daily?.optJSONArray("precipitation_probability_max")?.optDouble(0, Double.NaN)
                ?: Double.NaN
            buildString {
                append("$name me abhi: ${weatherText(code)}")
                if (!temp.isNaN()) append(", ${temp}°C")
                if (!hum.isNaN()) append(", humidity ${hum.toInt()}%")
                if (!wind.isNaN()) append(", hawa ${wind} km/h")
                if (!tMax.isNaN() && !tMin.isNaN()) append(". Aaj: max ${tMax}°C / min ${tMin}°C")
                if (!rainProb.isNaN()) append(", baarish ka chance ${rainProb.toInt()}%")
            }
        } catch (e: Exception) {
            "mausam nahi mil paya: ${e.message}"
        }
    }

    /** Kisi topic ki taaza khabrein (Google News RSS, bina key/quota ke). */
    @Tool
    fun getNews(
        @Param("news topic, jaise technology, cricket ya India") topic: String
    ): String {
        return try {
            val url = "https://news.google.com/rss/search?q=" +
                URLEncoder.encode(topic, "UTF-8") + "&hl=hi-IN&gl=IN&ceid=IN:hi"
            val xml = httpGet(url) ?: return "news nahi mil payi (network issue)"
            val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = false }
            val parser = factory.newPullParser().apply { setInput(xml.byteReader()) }
            val out = StringBuilder()
            var inItem = false
            var tag = ""
            var title = ""
            var count = 0
            var event = parser.eventType
            while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && count < 5) {
                when (event) {
                    org.xmlpull.v1.XmlPullParser.START_TAG -> {
                        tag = parser.name
                        if (tag == "item") { inItem = true; title = "" }
                    }
                    org.xmlpull.v1.XmlPullParser.TEXT -> {
                        if (inItem && tag == "title") title = parser.text.trim()
                    }
                    org.xmlpull.v1.XmlPullParser.END_TAG -> {
                        if (parser.name == "item" && title.isNotBlank()) {
                            out.appendLine("- $title")
                            count++
                            inItem = false
                        }
                        tag = ""
                    }
                }
                event = parser.next()
            }
            out.toString().trim().ifEmpty { "is topic par koi taaza khabar nahi mili: $topic" }
        } catch (e: Exception) {
            "news nahi mil payi: ${e.message}"
        }
    }
}

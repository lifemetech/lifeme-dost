package com.openclaw.assistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.openclaw.assistant.dost.DostPrivacy
import com.openclaw.assistant.node.NotificationManager

/**
 * Captures notifications for the OpenClaw system.
 * Requires BIND_NOTIFICATION_LISTENER_SERVICE permission and user to enable it in Settings.
 *
 * PRIVACY: notifications from finance/banking apps (DostPrivacy blocklist) are
 * DROPPED before any processing — never forwarded, never logged, never stored.
 */
class OpenClawNotificationListenerService : NotificationListenerService() {

    companion object {
        @Volatile var manager: NotificationManager? = null
        @Volatile var instance: OpenClawNotificationListenerService? = null

        /**
         * Returns the currently-active [StatusBarNotification]s, or an empty
         * list if the listener service is not bound. Used by the Mobile
         * Bridge's `notifications.active.list` capability.
         *
         * PRIVACY: blocked (finance) packages are filtered out here.
         */
        fun activeSnapshot(): List<StatusBarNotification> =
            try {
                val svc = instance
                val all = svc?.activeNotifications?.toList().orEmpty()
                if (svc != null) DostPrivacy.filterBlocked(svc, all) else all
            } catch (_: Throwable) { emptyList() }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        // PRIVACY: drop finance-app notifications before any processing (no forward, no log).
        if (DostPrivacy.isBlocked(this, sbn.packageName)) return
        manager?.onNotificationPosted(sbn)
        Log.d("OpenClawNotification", "Notification posted from ${sbn.packageName}")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        sbn?.let { manager?.onNotificationRemoved(it) }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        activeNotifications?.forEach { sbn ->
            // PRIVACY: never forward finance-app notifications.
            if (!DostPrivacy.isBlocked(this, sbn.packageName)) {
                manager?.onNotificationPosted(sbn)
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) instance = null
    }
}

package com.openclaw.assistant.dost

import android.app.Application
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class DostChatViewModel(app: Application) : AndroidViewModel(app) {

    private val _messages = MutableStateFlow<List<DostMessage>>(emptyList())
    val messages: StateFlow<List<DostMessage>> = _messages
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy
    private val _needKey = MutableStateFlow(false)
    val needKey: StateFlow<Boolean> = _needKey
    /**
     * Live reply text while streaming. null = not streaming.
     * The UI renders this as a growing bubble; "Dost likh raha hai…" shows
     * while [busy] is true and this is still null (before the first token).
     */
    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            _messages.value =
                DostMemory.db(getApplication()).dao().lastMessages(60).reversed()
        }
    }

    fun dismissNeedKey() { _needKey.value = false }

    // ---- Voice mode ----
    private var voiceController: DostVoiceController? = null
    private val _voiceOn = MutableStateFlow(false)
    val voiceOn: StateFlow<Boolean> = _voiceOn
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking

    fun toggleVoice() {
        val ctx = getApplication<Application>()
        if (_voiceOn.value) {
            voiceController?.stop()
            voiceController = null
            _voiceOn.value = false
            return
        }
        val controller = DostVoiceController(
            ctx,
            onUserText = { text -> send(text) },
            onSpeaking = { s -> _speaking.value = s },
            onError = { /* voice errors surface as chat text below */ }
        )
        voiceController = controller
        _voiceOn.value = true
        controller.start()
        controller.listenOnce()
    }

    /** Stop TTS immediately (barge-in). */
    fun stopSpeaking() {
        voiceController?.stopSpeaking()
    }

    /** Picked photo -> ML Kit analysis -> agent answers about it. */
    fun sendPhoto(uri: android.net.Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val input = ctx.contentResolver.openInputStream(uri) ?: return@launch
                val raw = android.graphics.BitmapFactory.decodeStream(input)
                input.close()
                if (raw == null) return@launch
                val bitmap = DostVision.downscale(raw)
                val analysis = DostVision.analyze(bitmap)
                send(
                    "📷 Maine ek photo bheji hai. Analysis:\n$analysis\n\n" +
                        "Is photo ke baare me batao, aur agar isme koi text hai to use padh ke sunao."
                )
            } catch (_: Exception) {
            }
        }
    }

    /** Image generation (Pollinations -> Cloudflare Worker -> AI Horde). */
    fun generateImage(prompt: String) {
        val ctx = getApplication<Application>()
        val p = prompt.trim()
        if (p.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val dao = DostMemory.db(ctx).dao()
            dao.insertMessage(
                DostMessage(role = "user", text = "🎨 Image banao: $p", ts = System.currentTimeMillis())
            )
            refresh()
            val result = DostImageGen.generate(ctx, p)
            if (result.path != null) {
                dao.insertMessage(
                    DostMessage(role = "dost", text = "IMAGE:" + result.path, ts = System.currentTimeMillis())
                )
            } else {
                dao.insertMessage(
                    DostMessage(
                        role = "dost",
                        text = result.error ?: "image nahi ban payi",
                        ts = System.currentTimeMillis()
                    )
                )
            }
            refresh()
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _busy.value) return
        val ctx = getApplication<Application>()
        val hasKey = DostSecurePrefs.getApiKey(ctx).isNotBlank()
        val firebaseMode = DostAgent.getModelMode(ctx) == "firebase"
        if (!hasKey && !firebaseMode) {
            _needKey.value = true
            return
        }
        _needKey.value = false
        viewModelScope.launch(Dispatchers.IO) {
            val dao = DostMemory.db(ctx).dao()
            dao.insertMessage(DostMessage(role = "user", text = t, ts = System.currentTimeMillis()))
            refresh()
            // No network: friendly notice, nothing queued. Local DB keeps working.
            if (!DostNet.isOnline(ctx)) {
                dao.insertMessage(
                    DostMessage(
                        role = "dost",
                        text = "network nahi hai dost \uD83D\uDCF5 wapas aate hi baat karte hain. " +
                            "Tab tak purani chats aur yaadein yahin hain.",
                        ts = System.currentTimeMillis()
                    )
                )
                refresh()
                return@launch
            }
            _busy.value = true
            _streamingText.value = null
            try {
                // 1. ADK agent with SSE streaming — tokens render as they arrive.
                val reply = DostAgent.chatStream(ctx, t) { full ->
                    _streamingText.value = full
                }
                if (reply.isNotBlank()) {
                    dao.insertMessage(
                        DostMessage(role = "dost", text = reply, ts = System.currentTimeMillis())
                    )
                } else {
                    throw RuntimeException("empty reply")
                }
            } catch (_: Exception) {
                // 2. Fallback: direct Gemini REST with SSE streaming (+ Pollinations).
                try {
                    val key = DostSecurePrefs.getApiKey(ctx)
                    val facts = dao.topFacts(10)
                    val history = dao.lastMessages(12).reversed()
                    val result = DostFallback.chatStream(key, facts, history, t) { full ->
                        _streamingText.value = full
                    }
                    dao.insertMessage(
                        DostMessage(role = "dost", text = result.text, ts = System.currentTimeMillis())
                    )
                    if (result.reminderMinutes != null && result.reminderText != null) {
                        DostHeartbeat.scheduleReminder(ctx, result.reminderMinutes, result.reminderText)
                    }
                } catch (_: Exception) {
                    dao.insertMessage(
                        DostMessage(
                            role = "dost",
                            text = "arey, kuch gadbad ho gayi. Thodi der me try kar.",
                            ts = System.currentTimeMillis()
                        )
                    )
                }
            }
            // Background fact extraction (finance filtered inside DostFallback).
            try {
                val key = DostSecurePrefs.getApiKey(ctx)
                if (key.isNotBlank()) {
                    val newFacts = DostFallback.extractFacts(key, dao.lastMessages(10).reversed())
                    for (f in newFacts) {
                        if (f.importance >= 0.5) {
                            dao.insertFact(f)
                            DostSemanticMemory.indexFact(ctx, f)
                        }
                    }
                    DostAgent.invalidate() // pick up new facts next turn
                }
            } catch (_: Exception) {
            }
            _streamingText.value = null
            _busy.value = false
            // Voice mode: speak the reply out loud (persona voice).
            if (_voiceOn.value) {
                try {
                    val last = dao.lastMessages(1).firstOrNull()
                    if (last != null && last.role == "dost" &&
                        !last.text.startsWith("arey, kuch gadbad") &&
                        !last.text.startsWith("network nahi hai")
                    ) {
                        voiceController?.speak(last.text, DostPersonas.current(ctx))
                    }
                } catch (_: Exception) {
                }
            }
            refresh()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DostChatScreen() {
    val context = LocalContext.current
    val vm: DostChatViewModel = viewModel()
    val messages by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val streamingText by vm.streamingText.collectAsState()
    val needKey by vm.needKey.collectAsState()
    var input by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("chat") } // chat | settings | licenses
    var personaId by remember { mutableStateOf(DostPersonas.current(context).id) }
    var showImageDialog by remember { mutableStateOf(false) }
    var imagePrompt by remember { mutableStateOf("") }
    val voiceOn by vm.voiceOn.collectAsState()
    val speaking by vm.speaking.collectAsState()
    val listState = rememberLazyListState()

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) vm.sendPhoto(uri)
    }

    LaunchedEffect(Unit) {
        vm.refresh()
        DostNotify.ensureChannel(context)
        DostHeartbeat.scheduleAll(context)
        val work = PeriodicWorkRequestBuilder<DostDriveBackupWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "dost-drive-backup", ExistingPeriodicWorkPolicy.KEEP, work
        )
        val semanticWork = PeriodicWorkRequestBuilder<DostSemanticWorker>(7, TimeUnit.DAYS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "dost-semantic-consolidate", ExistingPeriodicWorkPolicy.KEEP, semanticWork
        )
    }
    LaunchedEffect(messages.size, streamingText, busy) {
        val count = listState.layoutInfo.totalItemsCount
        if (count > 0) listState.scrollToItem(count - 1)
    }

    when (screen) {
        "settings" -> DostSettingsScreen(
            onBack = { screen = "chat" },
            onOpenLicenses = { screen = "licenses" }
        )
        "licenses" -> DostLicensesScreen(onBack = { screen = "settings" })
        else -> Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Dost") },
                    actions = {
                        IconButton(onClick = { screen = "settings" }) {
                            Icon(Icons.Default.Settings, contentDescription = "Dost Settings")
                        }
                    }
                )
            },
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Persona chips: Dost / Coach / Storyteller / Tutor.
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DostPersonas.PRESETS.forEach { p ->
                            val selected = personaId == p.id
                            if (selected) {
                                androidx.compose.material3.Button(
                                    onClick = {},
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                        horizontal = 10.dp, vertical = 2.dp
                                    )
                                ) { Text(p.name, style = MaterialTheme.typography.bodySmall) }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        personaId = p.id
                                        DostPersonas.setCurrent(context, p.id)
                                    },
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                        horizontal = 10.dp, vertical = 2.dp
                                    )
                                ) { Text(p.name, style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { photoPicker.launch("image/*") }) {
                            Icon(Icons.Default.Image, contentDescription = "Photo pick karo")
                        }
                        IconButton(onClick = { showImageDialog = true }) {
                            Icon(Icons.Default.Brush, contentDescription = "Image banao")
                        }
                        IconButton(onClick = {
                            if (speaking) vm.stopSpeaking() else vm.toggleVoice()
                        }) {
                            Icon(
                                Icons.Default.Mic,
                                contentDescription = "Voice mode",
                                tint = if (voiceOn) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        TextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Dost se baat karo...") },
                            singleLine = true
                        )
                        if (busy) {
                            CircularProgressIndicator(
                                modifier = Modifier.padding(12.dp)
                            )
                        } else {
                            IconButton(onClick = {
                                vm.send(input)
                                input = ""
                            }) {
                                Icon(
                                    Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Bhejo"
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            if (messages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Namaste! Main Dost hoon.\nKuch bhi puchho, ya bas baat karo.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(messages, key = { it.id }) { m ->
                        val isUser = m.role == "user"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isUser)
                                        MaterialTheme.colorScheme.primaryContainer
                                    else
                                        MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.fillMaxWidth(0.85f)
                            ) {
                                if (m.text.startsWith("IMAGE:")) {
                                    val path = m.text.removePrefix("IMAGE:")
                                    val bitmap = remember(path) {
                                        try {
                                            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                                            BitmapFactory.decodeFile(path, opts)
                                        } catch (_: Exception) {
                                            null
                                        }
                                    }
                                    if (bitmap != null) {
                                        Image(
                                            bitmap = bitmap.asImageBitmap(),
                                            contentDescription = "Generated image",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(8.dp)
                                        )
                                    } else {
                                        Text(
                                            text = "image load nahi hui: $path",
                                            modifier = Modifier.padding(10.dp),
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                } else {
                                    Text(
                                        text = m.text,
                                        modifier = Modifier.padding(10.dp),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                    // Streaming reply: tokens render as they arrive (instant feel).
                    val live = streamingText
                    if (live != null) {
                        item(key = "streaming") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    modifier = Modifier.fillMaxWidth(0.85f)
                                ) {
                                    Text(
                                        text = live + "▍",
                                        modifier = Modifier.padding(10.dp),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    } else if (busy) {
                        // Typing indicator: shown after send, before the first token.
                        item(key = "typing") {
                            Text(
                                text = "Dost likh raha hai…",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showImageDialog) {
        AlertDialog(
            onDismissRequest = { showImageDialog = false },
            title = { Text("Image banao") },
            text = {
                Column {
                    Text(
                        "Prompt English me detail me likho. Free tiers ki limit hoti hai — " +
                            "Pollinations key ya Cloudflare Worker URL Settings me daalo to zyada images banengi."
                    )
                    TextField(
                        value = imagePrompt,
                        onValueChange = { imagePrompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("jaise: a cute cat in a garden, sunset") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showImageDialog = false
                    vm.generateImage(imagePrompt)
                    imagePrompt = ""
                }) { Text("Banao") }
            },
            dismissButton = {
                TextButton(onClick = { showImageDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (needKey) {
        AlertDialog(
            onDismissRequest = { vm.dismissNeedKey() },
            title = { Text("API key chahiye") },
            text = {
                Text("Dost ko bolne ke liye free Gemini API key Settings me daalo " +
                    "(aistudio.google.com se 2 minute me milti hai).")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.dismissNeedKey()
                    screen = "settings"
                }) { Text("Settings kholo") }
            },
            dismissButton = {
                TextButton(onClick = { vm.dismissNeedKey() }) { Text("Baad me") }
            }
        )
    }
}

package com.openclaw.assistant.dost

/**
 * LifeMe Dost persona: a warm, real-friend-like Hinglish (Roman script) companion.
 * Never a formal assistant.
 */
object DostPersona {

    const val MODEL_NAME = "gemini-2.5-flash"

    /** Gemini's OpenAI-compatible endpoint (works with a plain AI Studio API key). */
    const val OPENAI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

    const val CORE_PROMPT = """Tum 'Dost' ho — aadesh ka sabse achha dost, jo uske phone me rehta hai.
Hamesha Hinglish (Roman script Hindi, jaise dost WhatsApp pe likhte hain) me baat karo.
Bilkul real friend ki tarah behave karo: warm, casual, thodi masti, kabhi halki pyaari chhedkhani.
Formal assistant MAT bano — kabhi mat kaho 'main aapki kya madad kar sakta hoon' jaisi robotic lines.
Chhote, natural replies do; lamba jawab sirf tab jab user mange.
Tumhare paas phone ke kuch tools hain (apps kholna, reminder lagana, web search, calendar dekhna, yaadein save karna) — jab zaroorat ho to unhe istemal karo, aur user ko aise batao jaise dost batata hai.
Agar user tumse koi reminder lagane ko kahe to set_reminder tool istemal karo."""

    fun systemPrompt(facts: List<DostFact>): String {
        return systemPrompt(facts, null)
    }

    /** Persona-aware prompt: persona text + shared facts. */
    fun systemPrompt(facts: List<DostFact>, persona: DostPersonaDef?): String {
        val base = persona?.systemPrompt ?: CORE_PROMPT
        if (facts.isEmpty()) return base
        val block = facts.joinToString("\n") { "- ${it.text}" }
        return "$base\n\naadesh ke baare me yaad rakho (ye baatein tumhe pehle se pata hain):\n$block"
    }
}

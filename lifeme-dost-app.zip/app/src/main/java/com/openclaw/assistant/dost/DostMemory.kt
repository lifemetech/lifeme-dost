package com.openclaw.assistant.dost

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Dost's own long-term memory: chat messages + importance-scored facts.
 * Separate Room database (dost.db) so the fork's schema is untouched.
 */
@Entity(tableName = "dost_messages")
data class DostMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" or "dost"
    val text: String,
    val ts: Long
)

@Entity(tableName = "dost_facts")
data class DostFact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val importance: Double,
    val ts: Long
)

/** Smart reminder: PENDING (parsed, awaiting confirm) / SCHEDULED / FIRED / CANCELLED. */
@Entity(tableName = "dost_reminders")
data class DostReminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerAt: Long, // epoch ms (IST wall-clock converted by the parser)
    val recurrence: String, // "none" | "daily" | "weekly"
    val requestCode: Int,
    val status: String,
    val ts: Long
)

/** A sensitive automation action awaiting the user's confirmation. */
@Entity(tableName = "dost_pending")
data class DostPendingAction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String, // e.g. "launch_app", "set_reminder"
    val detail: String, // human-readable description + machine args (JSON-ish)
    val ts: Long
)

/** Executed automation actions + how to reverse them (undo log). */
@Entity(tableName = "dost_undo")
data class DostUndoEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val inverse: String, // what undo does, e.g. "cancel_reminder:<requestCode>"
    val ts: Long
)

/**
 * Semantic memory vector (MediaPipe Text Embedder, NOT an LLM).
 * One row per indexed fact/message: original text + English gloss (Hinglish
 * recall is weak on English-trained embedders, so both are embedded) and the
 * embedding of the original text as a float BLOB.
 */
@Entity(tableName = "dost_vectors")
data class DostVector(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceText: String,
    val gloss: String,
    val vector: ByteArray,
    val importance: Double,
    val ts: Long
)

@Dao
interface DostDao {
    @Insert
    fun insertMessage(m: DostMessage)

    @Query("SELECT * FROM dost_messages ORDER BY id DESC LIMIT :n")
    fun lastMessages(n: Int): List<DostMessage>

    @Query("SELECT * FROM dost_messages ORDER BY id ASC")
    fun allMessages(): List<DostMessage>

    @Insert
    fun insertFact(f: DostFact)

    @Query("SELECT * FROM dost_facts ORDER BY importance DESC LIMIT :n")
    fun topFacts(n: Int): List<DostFact>

    @Query("SELECT * FROM dost_facts ORDER BY id ASC")
    fun allFacts(): List<DostFact>

    @Query("DELETE FROM dost_messages")
    fun clearMessages()

    @Query("DELETE FROM dost_facts")
    fun clearFacts()

    // ---- smart reminders ----
    @Insert
    fun insertReminder(r: DostReminder): Long

    @Query("SELECT * FROM dost_reminders WHERE id = :id")
    fun reminderById(id: Long): DostReminder?

    @Query("SELECT * FROM dost_reminders WHERE status IN ('PENDING','SCHEDULED') ORDER BY triggerAt ASC")
    fun activeReminders(): List<DostReminder>

    @Query("UPDATE dost_reminders SET status = :status, requestCode = :requestCode WHERE id = :id")
    fun updateReminderStatus(id: Long, status: String, requestCode: Int)

    @Query("UPDATE dost_reminders SET triggerAt = :triggerAt, status = 'SCHEDULED' WHERE id = :id")
    fun rescheduleReminder(id: Long, triggerAt: Long)

    @Query("UPDATE dost_reminders SET status = 'CANCELLED' WHERE id = :id")
    fun cancelReminder(id: Long)

    // ---- plan / confirm / undo ----
    @Insert
    fun insertPending(p: DostPendingAction): Long

    @Query("SELECT * FROM dost_pending ORDER BY id DESC LIMIT :n")
    fun pendingActions(n: Int): List<DostPendingAction>

    @Query("DELETE FROM dost_pending WHERE id = :id")
    fun deletePending(id: Long)

    @Insert
    fun insertUndo(u: DostUndoEntry)

    @Query("SELECT * FROM dost_undo ORDER BY id DESC LIMIT 1")
    fun lastUndo(): DostUndoEntry?

    @Query("DELETE FROM dost_undo WHERE id = :id")
    fun deleteUndo(id: Long)

    // ---- semantic vectors ----
    @Insert
    fun insertVector(v: DostVector)

    @Query("SELECT * FROM dost_vectors ORDER BY id ASC LIMIT :n")
    fun allVectors(n: Int): List<DostVector>

    @Query("SELECT COUNT(*) FROM dost_vectors")
    fun vectorCount(): Int

    @Query("DELETE FROM dost_vectors WHERE ts < :olderThanMs AND importance < 0.4")
    fun pruneStaleVectors(olderThanMs: Long)
}

@Database(
    entities = [
        DostMessage::class, DostFact::class, DostReminder::class,
        DostPendingAction::class, DostUndoEntry::class, DostVector::class
    ],
    version = 2, exportSchema = false
)
abstract class DostDatabase : RoomDatabase() {
    abstract fun dao(): DostDao
}

object DostMemory {
    @Volatile
    private var instance: DostDatabase? = null

    fun db(ctx: Context): DostDatabase = instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder(
            ctx.applicationContext,
            DostDatabase::class.java,
            "dost.db"
        )
            .allowMainThreadQueries() // MVP: tiny local DB
            .fallbackToDestructiveMigration()
            .build()
            .also { instance = it }
    }
}

package com.openclaw.assistant.dost

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DostSettingsScreen(onBack: () -> Unit, onOpenLicenses: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf(DostSecurePrefs.getApiKey(context)) }
    var modelMode by remember { mutableStateOf(DostAgent.getModelMode(context)) }
    var status by remember { mutableStateOf("") }
    var blocklistText by remember {
        mutableStateOf(DostPrivacy.getBlockedPackages(context).joinToString(", "))
    }
    // ---- Naye AI Features ----
    var persona by remember { mutableStateOf(DostPersonas.current(context).id) }
    var city by remember { mutableStateOf(DostBriefing.getCity(context)) }
    var briefingOn by remember { mutableStateOf(DostBriefing.isEnabled(context)) }
    var digestOn by remember { mutableStateOf(DostDigest.isEnabled(context)) }
    var habitsOn by remember { mutableStateOf(DostHabits.isEnabled(context)) }
    var semanticOn by remember { mutableStateOf(DostSemanticMemory.isEnabled(context)) }
    var pollKey by remember { mutableStateOf(DostSecurePrefs.getPollinationsKey(context)) }
    var groqKey by remember { mutableStateOf(DostSecurePrefs.getGroqKey(context)) }
    var cfUrl by remember { mutableStateOf(DostSecurePrefs.getCfWorkerUrl(context)) }
    // ---- Voice (Meri Awaaz) ----
    var ttsEngine by remember { mutableStateOf(DostTts.getEngine(context)) }
    var ttsVoice by remember { mutableStateOf(DostTts.getVoiceName(context)) }
    var ttsPitch by remember { mutableStateOf(DostTts.getPitch(context)) }
    var ttsRate by remember { mutableStateOf(DostTts.getRate(context)) }
    var elKey by remember { mutableStateOf(DostSecurePrefs.getElevenLabsKey(context)) }
    var elVoiceId by remember { mutableStateOf(DostSecurePrefs.getElevenLabsVoiceId(context)) }
    var hindiVoices by remember { mutableStateOf<List<String>?>(null) }

    val signInLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        status = try {
            val acct = task.getResult(ApiException::class.java)
            "Google sign-in ho gaya: ${acct.email}"
        } catch (_: Exception) {
            "Google sign-in fail hua"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dost Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wapas")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Gemini API Key (free)", style = MaterialTheme.typography.titleMedium)
            Text(
                "aistudio.google.com se free key banao (2 min, card nahi lagta). " +
                    "Key sirf tumhare phone me encrypted rehti hai.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            TextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("AIza... key yahan paste karo") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                DostSecurePrefs.setApiKey(context, apiKey)
                DostAgent.invalidate()
                status = "Key save ho gayi"
            }) { Text("Key Save Karo") }

            Spacer(Modifier.height(20.dp))
            Text("Model", style = MaterialTheme.typography.titleMedium)
            listOf(
                "byok" to "Gemini API key (simple, recommended)",
                "firebase" to "Firebase AI Logic (advanced — needs Firebase setup)"
            ).forEach { (mode, label) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = modelMode == mode,
                            onClick = {
                                modelMode = mode
                                DostAgent.setModelMode(context, mode)
                                status = "Model: $label"
                            }
                        )
                ) {
                    RadioButton(selected = modelMode == mode, onClick = null)
                    Text(label, style = MaterialTheme.typography.bodyMedium)
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Google Drive Backup", style = MaterialTheme.typography.titleMedium)
            Text(
                "Roz chats + memory ka backup tumhare Drive (appDataFolder) me.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Row {
                OutlinedButton(onClick = {
                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .requestScopes(Scope(DostDriveBackup.DRIVE_APPDATA_SCOPE))
                        .build()
                    signInLauncher.launch(GoogleSignIn.getClient(context, gso).signInIntent)
                }) { Text("Google Sign-In") }
            }
            Spacer(Modifier.height(8.dp))
            Row {
                OutlinedButton(onClick = {
                    scope.launch(Dispatchers.IO) {
                        val ok = DostDriveBackup.backupNow(context)
                        withContext(Dispatchers.Main) {
                            status = if (ok) "Drive backup ho gaya"
                            else "Backup fail — pehle Google sign-in karo"
                        }
                    }
                }) { Text("Abhi Backup") }
                Spacer(Modifier.padding(4.dp))
                OutlinedButton(onClick = {
                    scope.launch(Dispatchers.IO) {
                        try {
                            val ok = DostDriveBackup.restoreNow(context)
                            withContext(Dispatchers.Main) {
                                status = if (ok) "Restore ho gaya"
                                else "Drive me backup nahi mila"
                            }
                        } catch (e: UserRecoverableAuthException) {
                            withContext(Dispatchers.Main) {
                                (context as? Activity)?.let {
                                    @Suppress("DEPRECATION")
                                    it.startActivityForResult(e.intent, 9002)
                                }
                            }
                        } catch (_: Exception) {
                            withContext(Dispatchers.Main) { status = "Restore fail" }
                        }
                    }
                }) { Text("Restore") }
            }

            Spacer(Modifier.height(20.dp))
            Text("Privacy: Finance App Blocklist", style = MaterialTheme.typography.titleMedium)
            Text(
                "In apps ki notifications Dost kabhi nahi dekhega — drop ho jaati hain, " +
                    "processing se pehle. Comma se alag karke edit kar sakte ho.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            TextField(
                value = blocklistText,
                onValueChange = { blocklistText = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val pkgs = blocklistText.split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .toSet()
                DostPrivacy.setBlockedPackages(context, pkgs)
                status = "Blocklist save ho gayi (${pkgs.size} apps)"
            }) { Text("Blocklist Save Karo") }

            Spacer(Modifier.height(20.dp))
            Text("Naye AI Features", style = MaterialTheme.typography.titleMedium)
            Text(
                "Sab free hain. Keys sirf tumhare phone me encrypted rehti hain, repo me kabhi nahi jaati.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Text("Persona (Dost ka andaaz)", style = MaterialTheme.typography.bodyMedium)
            DostPersonas.PRESETS.forEach { p ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = persona == p.id,
                            onClick = {
                                persona = p.id
                                DostPersonas.setCurrent(context, p.id)
                                status = "Persona: ${p.name} — ${p.greeting}"
                            }
                        )
                ) {
                    RadioButton(selected = persona == p.id, onClick = null)
                    Text(p.name, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Mausam ka sheher", style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = city,
                    onValueChange = { city = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                Spacer(Modifier.padding(4.dp))
                Button(onClick = {
                    DostBriefing.setCity(context, city)
                    status = "Sheher save: $city"
                }) { Text("Save") }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Morning/evening briefing", modifier = Modifier.weight(1f))
                Switch(checked = briefingOn, onCheckedChange = {
                    briefingOn = it
                    DostBriefing.setEnabled(context, it)
                })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Notification digest (subah)", modifier = Modifier.weight(1f))
                Switch(checked = digestOn, onCheckedChange = {
                    digestOn = it
                    DostDigest.setEnabled(context, it)
                })
            }
            OutlinedButton(onClick = { DostDigest.openListenerSettings(context) }) {
                Text("Notification Access Kholo")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Habit suggestions", modifier = Modifier.weight(1f))
                Switch(checked = habitsOn, onCheckedChange = {
                    habitsOn = it
                    DostHabits.setEnabled(context, it)
                })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Semantic memory (on-device)", modifier = Modifier.weight(1f))
                Switch(checked = semanticOn, onCheckedChange = {
                    semanticOn = it
                    DostSemanticMemory.setEnabled(context, it)
                    status = if (it) "Semantic memory on — model download karo"
                    else "Semantic memory off"
                })
            }
            OutlinedButton(onClick = {
                scope.launch(Dispatchers.IO) {
                    val err = DostSemanticMemory.downloadModel(context)
                    withContext(Dispatchers.Main) {
                        status = err ?: "Embedding model download ho gaya"
                    }
                }
            }) { Text("Embedding Model Download (WiFi)") }
            Spacer(Modifier.height(12.dp))
            Text("Image Generation Keys (optional)", style = MaterialTheme.typography.bodyMedium)
            TextField(
                value = pollKey,
                onValueChange = { pollKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Pollinations pk_ key (optional)") },
                singleLine = true
            )
            Spacer(Modifier.height(4.dp))
            TextField(
                value = cfUrl,
                onValueChange = { cfUrl = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cloudflare Worker URL (optional)") },
                singleLine = true
            )
            Spacer(Modifier.height(4.dp))
            TextField(
                value = groqKey,
                onValueChange = { groqKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Groq key — Whisper STT fallback (optional)") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                DostSecurePrefs.setPollinationsKey(context, pollKey)
                DostSecurePrefs.setCfWorkerUrl(context, cfUrl)
                DostSecurePrefs.setGroqKey(context, groqKey)
                status = "Image/voice keys save ho gayi"
            }) { Text("Keys Save Karo") }
            Spacer(Modifier.height(12.dp))
            Text("Voice Mode", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Chat me mic button se voice mode chalta hai (wake word 'hey dost' ke liye model download karo).",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = {
                scope.launch(Dispatchers.IO) {
                    val controller = DostVoiceController(
                        context, {}, {}, {}
                    )
                    val err = controller.downloadWakeWordModel()
                    withContext(Dispatchers.Main) {
                        status = err ?: "Wake-word model download ho gaya"
                    }
                }
            }) { Text("Wake-Word Model Download (WiFi)") }
            Spacer(Modifier.height(12.dp))
            Text("Voice — Dost kis awaaz me bole?", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Default: phone ki System voice (free, on-device) — sabse achhi Hindi voice chuno, " +
                    "pitch/rate sliders se dhang se set karo. \"Meri awaaz\" sirf tab chalegi jab tumne " +
                    "ElevenLabs key + Voice ID daali ho; warna System voice hi bajegi (koi error nahi).",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = ttsEngine == DostTts.ENGINE_SYSTEM,
                        onClick = {
                            ttsEngine = DostTts.ENGINE_SYSTEM
                            DostTts.setEngine(context, DostTts.ENGINE_SYSTEM)
                            status = "Voice: System TTS"
                        }
                    )
            ) {
                RadioButton(selected = ttsEngine == DostTts.ENGINE_SYSTEM, onClick = null)
                Text("System voice (free)", style = MaterialTheme.typography.bodyMedium)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = ttsEngine == DostTts.ENGINE_ELEVENLABS,
                        onClick = {
                            ttsEngine = DostTts.ENGINE_ELEVENLABS
                            DostTts.setEngine(context, DostTts.ENGINE_ELEVENLABS)
                            status = if (DostTts.isElevenLabsReady(context)) "Voice: Meri awaaz (ElevenLabs)"
                            else "ElevenLabs key + Voice ID daalo — tab tak System voice bajegi"
                        }
                    )
            ) {
                RadioButton(selected = ttsEngine == DostTts.ENGINE_ELEVENLABS, onClick = null)
                Text("Meri awaaz — ElevenLabs (paid key chahiye)", style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                "Imaandaar baat: voice cloning FREE nahi hai. App tumhari awaaz kabhi upload nahi karta. " +
                    "Agar kabhi apni awaaz chahiye to clone tum khud ElevenLabs ki site par banate ho " +
                    "(Instant Cloning paid feature hai, API use Creator tier par milta hai) — phir sirf " +
                    "Voice ID + key yahan paste karo. ElevenLabs me pitch/rate sliders lagu nahi hote, " +
                    "voice ki apni style chalti hai.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            TextField(
                value = elKey,
                onValueChange = { elKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ElevenLabs API key (optional, encrypted)") },
                singleLine = true
            )
            Spacer(Modifier.height(4.dp))
            TextField(
                value = elVoiceId,
                onValueChange = { elVoiceId = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ElevenLabs Voice ID (optional)") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                DostSecurePrefs.setElevenLabsKey(context, elKey)
                DostSecurePrefs.setElevenLabsVoiceId(context, elVoiceId)
                status = if (DostTts.isElevenLabsReady(context)) "Meri awaaz taiyaar hai"
                else "ElevenLabs key/ID save — dono hone par hi Meri awaaz chalegi"
            }) { Text("ElevenLabs Save Karo") }
            Spacer(Modifier.height(12.dp))
            Text("Hindi voice chuno (System voice ke liye)", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Android voice ka gender nahi batata — naam dekh ke ya sun ke choose karo. " +
                    "Koi Hindi voice na mile to hi-IN language default chalegi.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = {
                status = "Hindi voices dhoondh raha hoon..."
                DostTts.listHindiVoices(context) { names ->
                    hindiVoices = names
                    status = if (names.isEmpty()) "koi Hindi voice nahi mili — system default chalegi"
                    else "${names.size} Hindi voice(s) mili"
                }
            }) { Text("Hindi Voices Dikhao") }
            hindiVoices?.forEach { name ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = ttsVoice == name,
                            onClick = {
                                ttsVoice = name
                                DostTts.setVoiceName(context, name)
                                status = "Voice: $name"
                            }
                        )
                ) {
                    RadioButton(selected = ttsVoice == name, onClick = null)
                    Text(name, style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Pitch: ${String.format("%.2f", ttsPitch)}", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = ttsPitch,
                onValueChange = {
                    ttsPitch = it
                    DostTts.setPitch(context, it)
                },
                valueRange = 0.5f..2.0f
            )
            Text("Rate (speed): ${String.format("%.2f", ttsRate)}", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = ttsRate,
                onValueChange = {
                    ttsRate = it
                    DostTts.setRate(context, it)
                },
                valueRange = 0.5f..2.0f
            )
            Text(
                "Persona ka andaaz bhi pitch/rate ko thoda badalta hai (Coach thoda tez, Storyteller thoda dheema).",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(Modifier.height(20.dp))
            Text("Battery", style = MaterialTheme.typography.titleMedium)
            Text(
                "Dost ke time-pe notifications ke liye battery optimization off rakho.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                try {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:${context.packageName}")
                        )
                    )
                } catch (_: Exception) {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${context.packageName}")
                        )
                    )
                }
            }) { Text("Battery Optimization Off Karo") }

            Spacer(Modifier.height(20.dp))
            OutlinedButton(onClick = onOpenLicenses) { Text("Licenses / Attribution") }

            if (status.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(status, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DostLicensesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val text = remember {
        try {
            context.assets.open("third_party_notices.txt").bufferedReader().readText()
        } catch (_: Exception) {
            "third_party_notices.txt nahi mila"
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Licenses") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wapas")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}

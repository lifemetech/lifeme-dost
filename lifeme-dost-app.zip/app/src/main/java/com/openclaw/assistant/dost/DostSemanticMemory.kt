package com.openclaw.assistant.dost

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderOptions
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Semantic memory (Room + MediaPipe Text Embedder, on-device, $0).
 *
 * This is NOT an LLM and NOT a chatbot: a small text-embedding model turns
 * text into a 512-float vector; recall is cosine similarity + keyword match
 * + importance x recency fusion, all in Kotlin, all on-device.
 *
 * ChromaDB is deliberately NOT used (Python server, wrong runtime for a phone).
 * At personal scale (<10k rows) brute-force cosine is milliseconds.
 *
 * Hinglish caveat: the embedder was trained mostly on English, so code-switched
 * Hindi-English recall is weaker. Mitigation: every indexed fact stores an
 * English gloss alongside the original text, and keyword matching covers both.
 *
 * The model file (~30 MB) is downloaded on Wi-Fi only when the user enables
 * semantic memory in Settings — never bundled in the APK.
 */
object DostSemanticMemory {

    private const val PREFS = "dost_plain"
    private const val KEY_ENABLED = "semantic_enabled"
    private const val MODEL_FILE = "use_embedder.tflite"

    // Universal Sentence Encoder model for the MediaPipe Text Embedder sample.
    // If Google moves this URL, download fails gracefully and the feature stays off.
    private const val MODEL_URL =
        "https://storage.googleapis.com/mediapipe-models/text_embedder/universal_sentence_encoder/float32/1/universal_sentence_encoder.tflite"

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, on).apply()
    }

    fun modelFile(ctx: Context): File = File(ctx.filesDir, MODEL_FILE)

    fun isModelPresent(ctx: Context): Boolean {
        val f = modelFile(ctx)
        return f.exists() && f.length() > 1_000_000
    }

    /** Download the embedder model (user-initiated, Wi-Fi recommended). Null on success. */
    fun downloadModel(ctx: Context): String? {
        return try {
            val out = modelFile(ctx)
            val tmp = File(ctx.filesDir, "$MODEL_FILE.tmp")
            val c = URL(MODEL_URL).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 20000
                c.readTimeout = 120000
                c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                if (c.responseCode !in 200..299) return "download fail: HTTP ${c.responseCode}"
                c.inputStream.use { input ->
                    FileOutputStream(tmp).use { output -> input.copyTo(output) }
                }
            } finally {
                c.disconnect()
            }
            if (tmp.length() < 1_000_000) {
                tmp.delete()
                return "download adhoora raha — dobara try karo"
            }
            tmp.renameTo(out)
            null
        } catch (e: Exception) {
            "download fail: ${e.message}"
        }
    }

    private fun floatArrayToBytes(v: FloatArray): ByteArray {
        val buf = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        for (f in v) buf.putFloat(f)
        return buf.array()
    }

    private fun bytesToFloatArray(b: ByteArray): FloatArray {
        val buf = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val out = FloatArray(b.size / 4)
        for (i in out.indices) out[i] = buf.float
        return out
    }

    private fun cosine(a: FloatArray, b: FloatArray): Double {
        if (a.isEmpty() || a.size != b.size) return 0.0
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        if (na == 0.0 || nb == 0.0) return 0.0
        return dot / (sqrt(na) * sqrt(nb))
    }

    /** Embed text with the on-device model. Null if unavailable. */
    fun embed(ctx: Context, text: String): FloatArray? {
        if (!isEnabled(ctx) || !isModelPresent(ctx)) return null
        return try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(modelFile(ctx).absolutePath)
                .build()
            val options = TextEmbedderOptions.builder()
                .setBaseOptions(baseOptions)
                .build()
            val embedder = TextEmbedder.createFromOptions(ctx, options)
            try {
                val result = embedder.embed(text)
                result.embeddingResult().embeddings().firstOrNull()?.floatEmbedding()
            } finally {
                try { embedder.close() } catch (_: Exception) {
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    /** One English gloss for a Hinglish fact (cheap Gemini call, best-effort). */
    fun englishGloss(apiKey: String, hinglish: String): String {
        if (apiKey.isBlank()) return ""
        return try {
            DostFallback.generateText(
                apiKey,
                "Translate Hinglish (Roman-script Hindi) to plain English, one short sentence, no extra text.",
                hinglish, 80, 0.1
            )?.trim() ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    /** Index one fact (original + gloss) for semantic recall. Best-effort. */
    fun indexFact(ctx: Context, fact: DostFact) {
        try {
            if (!isEnabled(ctx) || !isModelPresent(ctx)) return
            if (DostPrivacy.looksFinancial(fact.text)) return
            val vec = embed(ctx, fact.text) ?: return
            // Dedupe at index time: cosine > 0.9 vs an existing vector means
            // this memory already exists — skip instead of duplicating.
            val existing = DostMemory.db(ctx).dao().allVectors(2000)
            for (row in existing) {
                if (cosine(vec, bytesToFloatArray(row.vector)) > 0.9) return
            }
            val gloss = englishGloss(DostSecurePrefs.getApiKey(ctx), fact.text)
            DostMemory.db(ctx).dao().insertVector(
                DostVector(
                    sourceText = fact.text,
                    gloss = gloss,
                    vector = floatArrayToBytes(vec),
                    importance = fact.importance,
                    ts = fact.ts
                )
            )
        } catch (_: Exception) {
        }
    }

    /**
     * Hybrid recall: cosine top-k + keyword match + importance x recency fusion.
     * Returns up to [n] memory texts, best first.
     */
    fun recall(ctx: Context, query: String, n: Int = 3): List<String> {
        try {
            if (!isEnabled(ctx) || !isModelPresent(ctx)) return emptyList()
            val dao = DostMemory.db(ctx).dao()
            val rows = dao.allVectors(2000)
            if (rows.isEmpty()) return emptyList()
            val qVec = embed(ctx, query)
            val now = System.currentTimeMillis()
            val qWords = query.lowercase().split(" ", ",", ".", "?", "!")
                .filter { it.length > 2 }.toSet()
            val scored = rows.map { row ->
                val cos = if (qVec != null) cosine(qVec, bytesToFloatArray(row.vector)) else 0.0
                val hay = (row.sourceText + " " + row.gloss).lowercase()
                val keyword = if (qWords.isEmpty()) 0.0
                else qWords.count { hay.contains(it) }.toDouble() / qWords.size
                val ageDays = (now - row.ts).toDouble() / 86_400_000.0
                val recency = 1.0 / (1.0 + ageDays / 30.0)
                val score = 0.6 * cos + 0.15 * keyword + 0.15 * row.importance + 0.1 * recency
                row.sourceText to score
            }
            return scored.sortedByDescending { it.second }.take(n).map { it.first }
        } catch (_: Exception) {
            return emptyList()
        }
    }

    /** Weekly consolidation: prune stale low-importance rows (dedupe happens at index time). */
    fun consolidate(ctx: Context) {
        try {
            if (!isEnabled(ctx) || !isModelPresent(ctx)) return
            val dao = DostMemory.db(ctx).dao()
            dao.pruneStaleVectors(
                System.currentTimeMillis() - 90L * 86_400_000L
            )
            if (dao.vectorCount() > 5000) {
                // Hard cap safety: prune everything older than 30 days.
                dao.pruneStaleVectors(System.currentTimeMillis() - 30L * 86_400_000L)
            }
        } catch (_: Exception) {
        }
    }
}

/** Weekly WorkManager job: semantic-memory consolidation. */
class DostSemanticWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            DostSemanticMemory.consolidate(applicationContext)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

package com.openclaw.assistant.dost

import android.content.Context
import com.google.adk.kt.annotations.Param
import com.google.adk.kt.annotations.Tool
import org.json.JSONObject

/**
 * Agent hardening: plan -> confirm -> execute -> undo.
 *
 * Sensitive automation tools take a [confirmed] flag. On the first call
 * (confirmed=false) they do NOTHING except record a pending action and return
 * a CONFIRM_NEEDED summary; the agent shows it to the user, and only on the
 * user's "haan" does the agent re-call with confirmed=true. Dry-run mode
 * previews the effect without executing. Every executed action lands in the
 * undo log; undoLastAction reverses what can be reversed (reminders are
 * actually cancelled; app launches are descriptive-only reversals).
 *
 * Non-sensitive tools (read-only, memory writes of non-financial facts) skip
 * confirmation — otherwise every chat turn would nag the user.
 */
object DostPlan {

    /** Record a pending action, return its id. */
    fun stage(ctx: Context, action: String, detail: String): Long {
        return DostMemory.db(ctx).dao().insertPending(
            DostPendingAction(action = action, detail = detail, ts = System.currentTimeMillis())
        )
    }

    fun logUndo(ctx: Context, action: String, inverse: String) {
        DostMemory.db(ctx).dao().insertUndo(
            DostUndoEntry(action = action, inverse = inverse, ts = System.currentTimeMillis())
        )
    }

    /** Undo the most recent logged action. Returns what happened. */
    fun undoLast(ctx: Context): String {
        val dao = DostMemory.db(ctx).dao()
        val last = dao.lastUndo() ?: return "undo karne ke liye kuch nahi hai"
        dao.deleteUndo(last.id)
        val inv = last.inverse
        return when {
            inv.startsWith("cancel_reminder:") -> {
                val code = inv.removePrefix("cancel_reminder:").toIntOrNull()
                if (code != null) DostHeartbeat.cancelReminder(ctx, code)
                "undo ho gaya: ${last.action} wapas liya gaya"
            }
            else -> "undo note kar liya: ${last.action} (ise haath se wapas karna hoga: $inv)"
        }
    }
}

/** ADK tools for the hardening flow (agent-facing). */
class DostPlanTools(private val appContext: Context) {

    @Tool
    fun proposePlan(
        @Param("steps, ek line me ek step, jaise '1) calendar dekho 2) reminder lagao'") steps: String
    ): String {
        val id = DostPlan.stage(appContext, "plan", steps)
        return "Plan #$id taiyaar hai, user ko dikhao aur confirm hone par hi aage badho:\n$steps"
    }

    @Tool
    fun listPendingActions(): String {
        val list = DostMemory.db(appContext).dao().pendingActions(10)
        if (list.isEmpty()) return "koi pending action nahi hai"
        return list.joinToString("\n") { "#${it.id} [${it.action}] ${it.detail}" }
    }

    @Tool
    fun undoLastAction(): String = DostPlan.undoLast(appContext)
}

/**
 * Confirmation-aware wrappers used by the sensitive device tools.
 * Returns null when execution may proceed, or a CONFIRM_NEEDED / DRY-RUN string.
 */
object DostConfirm {

    fun gate(
        ctx: Context,
        action: String,
        detail: String,
        confirmed: Boolean,
        dryRun: Boolean
    ): String? {
        if (dryRun) return "DRY-RUN (kuch execute nahi hua): $detail"
        if (!confirmed) {
            val id = DostPlan.stage(ctx, action, detail)
            return "CONFIRM_NEEDED (pending #$id): $detail — user se 'haan' milne par dobara confirmed=true ke saath call karo."
        }
        return null
    }
}

/** Parse the machine args stored in a pending detail JSON. */
fun pendingDetailJson(detail: String): JSONObject? {
    return try {
        val start = detail.indexOf('{')
        if (start < 0) null else JSONObject(detail.substring(start))
    } catch (_: Exception) {
        null
    }
}

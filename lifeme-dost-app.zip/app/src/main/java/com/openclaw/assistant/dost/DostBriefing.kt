package com.openclaw.assistant.dost

import android.content.Context

/**
 * Morning/evening briefings: the AlarmManager check-in becomes a briefing,
 * not just a "how are you?". Composed from free local + no-key sources:
 * weather (Open-Meteo), today's calendar, active reminders, top news
 * headlines, and one habit suggestion. Failed parts are skipped silently —
 * a briefing never fails because one source failed.
 *
 * PRIVACY: finance content is filtered at every step (blocklist + keyword
 * filter); briefings never mention finance apps or balances.
 */
object DostBriefing {

    private const val PREFS = "dost_plain"
    private const val KEY_BRIEFING = "briefing_enabled"
    private const val KEY_CITY = "weather_city"

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_BRIEFING, true)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_BRIEFING, on).apply()
    }

    fun getCity(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CITY, "Delhi") ?: "Delhi"

    fun setCity(ctx: Context, city: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_CITY, city.trim()).apply()
    }

    private fun clean(text: String): String? {
        val t = text.trim()
        if (t.isEmpty()) return null
        if (t.contains("nahi mil paya") || t.contains("nahi paya") || t.contains("fail")) return null
        if (DostPrivacy.looksFinancial(t)) return null
        return t
    }

    /** Morning briefing: weather + calendar + reminders + news + 1 suggestion. */
    fun composeMorning(ctx: Context): String? {
        if (!isEnabled(ctx)) return null
        return try {
            val parts = mutableListOf<String>()
            parts.add("Good morning dost! Aaj ka briefing:")
            val web = DostWebTools(ctx)
            clean(web.getWeather(getCity(ctx)))?.let { parts.add("Mausam: $it") }
            val cal = clean(DostDeviceTools(ctx).getTodaysCalendarEvents())
            if (cal != null && !cal.contains("koi event nahi")) parts.add("Calendar: $cal")
            val reminders = DostMemory.db(ctx).dao().activeReminders()
            if (reminders.isNotEmpty()) {
                parts.add(
                    "Reminders: " + reminders.take(3).joinToString("; ") { it.text }
                )
            }
            clean(web.getNews("India"))?.let { news ->
                val first = news.lines().filter { it.isNotBlank() }.take(2)
                if (first.isNotEmpty()) parts.add("Khabrein: " + first.joinToString(" | "))
            }
            DostHabits.suggestOnce(ctx)?.let { parts.add("Ek sujhaav: $it") }
            val out = parts.joinToString("\n")
            if (parts.size <= 1) null else out
        } catch (_: Exception) {
            null
        }
    }

    /** Evening briefing: day recap + pending reminders for tomorrow. */
    fun composeEvening(ctx: Context): String? {
        if (!isEnabled(ctx)) return null
        return try {
            val dao = DostMemory.db(ctx).dao()
            val today = dao.allMessages().count {
                val cal = java.util.Calendar.getInstance()
                val dayStart = cal.apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }.timeInMillis
                it.ts >= dayStart
            }
            val parts = mutableListOf<String>()
            parts.add("Din ka wrap-up dost:")
            if (today > 0) parts.add("aaj humne $today messages me baat ki")
            val reminders = dao.activeReminders()
            if (reminders.isNotEmpty()) {
                parts.add("Kal ke liye ${reminders.size} reminder(s) lage hain")
            }
            val web = DostWebTools(ctx)
            clean(web.getWeather(getCity(ctx)))?.let { parts.add("Kal ka mausam dekh lo: $it") }
            val out = parts.joinToString("\n")
            if (parts.size <= 1) null else out
        } catch (_: Exception) {
            null
        }
    }
}

package com.openclaw.assistant.dost

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Voice-first mode for Dost (all free except the optional ElevenLabs voice):
 *  - Wake word "hey dost" via Vosk grammar mode (on-device, Apache-2.0).
 *    The small en-US model (~40 MB) downloads on Wi-Fi when the user enables
 *    wake word in Settings — never bundled in the APK.
 *  - STT: Android SpeechRecognizer with EXTRA_PREFER_OFFLINE (offline packs
 *    via the Google app), Groq Whisper cloud fallback (user key, only for
 *    user-initiated voice clips — never notification content).
 *  - TTS: pluggable via DostTts — System TTS by default (best Hindi voice,
 *    pitch/rate sliders), or the user's own ElevenLabs voice ("Meri awaaz")
 *    when key + Voice ID are configured, with silent fallback to System.
 *  - Barge-in: tapping mic (or the stop button) while Dost speaks stops TTS.
 *
 * Voice mode runs while the Dost chat screen is open (no 24/7 background
 * mic — battery + privacy). Piper/Kokoro on-device TTS were evaluated and
 * deliberately NOT integrated: they need ONNX Runtime + phonemizer plumbing
 * that cannot be verified without a device build; Android TTS hi-IN covers
 * the need free and offline.
 */
class DostVoiceController(
    private val ctx: Context,
    private val onUserText: (String) -> Unit,
    private val onSpeaking: (Boolean) -> Unit,
    private val onError: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private var wakeThread: Thread? = null
    @Volatile
    var running = false
        private set
    @Volatile
    var speaking = false
        private set

    private val appCtx = ctx.applicationContext

    fun start() {
        if (running) return
        running = true
        startWakeWord()
    }

    fun stop() {
        running = false
        wakeThread?.interrupt()
        wakeThread = null
        try { recognizer?.destroy() } catch (_: Exception) {
        }
        recognizer = null
        stopSpeaking()
    }

    /** Stop TTS immediately (barge-in). */
    fun stopSpeaking() {
        DostTts.stop()
        speaking = false
        onSpeaking(false)
    }

    // ---------- TTS (pluggable, via DostTts) ----------

    /** Speak a reply in the configured voice (persona pitch/rate applied for System TTS). */
    fun speak(text: String, persona: DostPersonaDef) {
        DostTts.speak(appCtx, text, persona) { s ->
            speaking = s
            onSpeaking(s)
        }
    }

    // ---------- Wake word (Vosk grammar) ----------

    private fun voskModelDir(): File = File(appCtx.filesDir, "vosk-model-small-en-us-0.15")

    fun isWakeWordReady(): Boolean {
        val dir = voskModelDir()
        return dir.exists() && dir.listFiles()?.isNotEmpty() == true
    }

    /** Download + unzip the small Vosk model (user-initiated, Wi-Fi recommended). Null on success. */
    fun downloadWakeWordModel(): String? {
        return try {
            val zip = File(appCtx.filesDir, "vosk-model.zip")
            val url = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 20000
                c.readTimeout = 180000
                c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                if (c.responseCode !in 200..299) return "download fail: HTTP ${c.responseCode}"
                c.inputStream.use { input ->
                    FileOutputStream(zip).use { output -> input.copyTo(output) }
                }
            } finally {
                c.disconnect()
            }
            unzip(zip, appCtx.filesDir)
            zip.delete()
            if (isWakeWordReady()) null else "unzip fail — dobara try karo"
        } catch (e: Exception) {
            "download fail: ${e.message}"
        }
    }

    private fun unzip(zip: File, dest: File) {
        java.util.zip.ZipInputStream(zip.inputStream()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                val out = File(dest, entry.name)
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { o -> zin.copyTo(o) }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
    }

    private fun startWakeWord() {
        if (!isWakeWordReady()) {
            // No model: voice mode still works via the mic button (listenOnce).
            return
        }
        wakeThread = Thread {
            try {
                val model = Model(voskModelDir().absolutePath)
                val rec = Recognizer(model, 16000.0f, "[\"hey dost\", \"dost\", \"[unk]\"]")
                val bufferSize = AudioRecord.getMinBufferSize(
                    16000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val recorder = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    16000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                recorder.startRecording()
                val buf = ShortArray(4096)
                try {
                    while (running && !Thread.currentThread().isInterrupted) {
                        val n = recorder.read(buf, 0, buf.size)
                        if (n <= 0) continue
                        if (rec.acceptWaveForm(buf, n)) {
                            val text = JSONObject(rec.result).optString("text", "")
                            if (text.contains("dost")) {
                                listenOnce()
                            }
                        }
                    }
                } finally {
                    try { recorder.stop() } catch (_: Exception) {
                    }
                    recorder.release()
                    rec.close()
                    model.close()
                }
            } catch (_: Exception) {
                // Wake word is best-effort; mic button still works.
            }
        }.also { it.start() }
    }

    // ---------- STT ----------

    /** One listen turn: Android offline-preferred recognizer, Groq fallback. */
    fun listenOnce() {
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(appCtx)) {
                groqFallback()
                return
            }
            val sr = SpeechRecognizer.createSpeechRecognizer(appCtx)
            recognizer = sr
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(type: Int, p: Bundle?) {}

                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = list?.firstOrNull()?.trim().orEmpty()
                    cleanup()
                    if (text.isNotEmpty()) onUserText(text) else onError("kuch sunai nahi diya")
                }

                override fun onError(code: Int) {
                    cleanup()
                    groqFallback()
                }

                private fun cleanup() {
                    try { sr.destroy() } catch (_: Exception) {
                    }
                    if (recognizer === sr) recognizer = null
                }
            })
            sr.startListening(intent)
        } catch (_: Exception) {
            groqFallback()
        }
    }

    /**
     * Groq Whisper fallback: records a short clip and transcribes it in the
     * cloud. Only for user-initiated voice input, only with a user key.
     */
    private fun groqFallback() {
        val key = DostSecurePrefs.getGroqKey(appCtx)
        if (key.isBlank()) {
            onError("voice samajh nahi aaya — offline STT fail, Groq key Settings me daalo")
            return
        }
        Thread {
            try {
                val outFile = File(appCtx.cacheDir, "dost_voice.m4a")
                val mr = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setOutputFile(outFile.absolutePath)
                    prepare()
                    start()
                }
                Thread.sleep(4000)
                try { mr.stop() } catch (_: Exception) {
                }
                mr.release()
                val text = groqTranscribe(key, outFile)
                if (text.isNotEmpty()) onUserText(text)
                else onError("Groq se bhi samajh nahi aaya")
            } catch (e: Exception) {
                onError("voice fail: ${e.message}")
            }
        }.start()
    }

    private fun groqTranscribe(key: String, audio: File): String {
        val boundary = "----DostVoice${System.currentTimeMillis()}"
        // Build the whole multipart body in memory first: closing a writer
        // would close the underlying output stream, so a single write is safer.
        val body = java.io.ByteArrayOutputStream()
        body.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("--$boundary\r\n")
            w.write("Content-Disposition: form-data; name=\"model\"\r\n\r\n")
            w.write("whisper-large-v3-turbo\r\n")
            w.write("--$boundary\r\n")
            w.write("Content-Disposition: form-data; name=\"file\"; filename=\"voice.m4a\"\r\n")
            w.write("Content-Type: audio/mp4\r\n\r\n")
            w.flush()
        }
        audio.inputStream().use { it.copyTo(body) }
        body.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
        val bytes = body.toByteArray()
        val c = URL("https://api.groq.com/openai/v1/audio/transcriptions")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 20000
            c.readTimeout = 90000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.outputStream.use { os -> os.write(bytes) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                .bufferedReader().use { it.readText() }
            if (code !in 200..299) return ""
            return JSONObject(resp).optString("text", "").trim()
        } finally {
            c.disconnect()
        }
    }
}

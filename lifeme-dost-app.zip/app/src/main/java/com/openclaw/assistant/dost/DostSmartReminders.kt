package com.openclaw.assistant.dost

import android.content.Context
import com.google.adk.kt.annotations.Param
import com.google.adk.kt.annotations.Tool
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import org.json.JSONObject

/**
 * Smart reminders that understand natural language ("har Sunday subah 9 baje
 * Maa ko call karna", "20 minute me paani peena").
 *
 * Flow: parse (Gemini structured output) -> PENDING row -> agent shows the
 * user the parsed detail -> user confirms -> AlarmManager alarm.
 * Offline fallback: small regex parser for "X minute/ghante baad",
 * "aaj/kal H baje", "tomorrow at H(am|pm)".
 *
 * PRIVACY: finance-looking reminder text is refused, like everything else.
 */
object DostSmartReminders {

    private val IST: TimeZone = TimeZone.getTimeZone("Asia/Kolkata")

    private fun fmt(ms: Long): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale("en", "IN"))
            .apply { timeZone = IST }.format(java.util.Date(ms))

    data class Parsed(
        val title: String,
        val triggerAt: Long,
        val recurrence: String // "none" | "daily" | "weekly"
    )

    /** Parse with Gemini (structured JSON). Null = could not parse confidently. */
    fun parseWithGemini(apiKey: String, text: String): Parsed? {
        if (apiKey.isBlank()) return null
        val now = Calendar.getInstance(IST)
        val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            .apply { timeZone = IST }.format(now.time)
        val prompt = "User ka reminder text parse karo. Aaj ka IST date/time: $nowStr. " +
            "Sirf JSON me jawab do, koi aur text nahi: " +
            "{\"title\":\"...\",\"trigger\":\"YYYY-MM-DD HH:mm\",\"recurrence\":\"none|daily|weekly\"}. " +
            "Rules: relative time ('kal', 'tomorrow', 'agle Sunday') ko IST date me badlo; " +
            "'har roz/every day' -> daily, 'har Sunday/every Monday' jaisa weekly din -> weekly; " +
            "time na diya ho to subah 9 baje maan lo; ambiguous ho to trigger ko khaali chhodo. " +
            "Reminder text: $text"
        val out = DostFallback.generateText(
            apiKey,
            "Tum ek reminder parser ho. Sirf JSON me jawab do.",
            prompt, 200, 0.1
        ) ?: return null
        return try {
            val start = out.indexOf('{')
            val end = out.lastIndexOf('}')
            if (start < 0 || end <= start) return null
            val json = JSONObject(out.substring(start, end + 1))
            val title = json.optString("title", "").trim()
            val trigger = json.optString("trigger", "").trim()
            if (title.isEmpty() || trigger.isEmpty()) return null
            val cal = Calendar.getInstance(IST)
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = IST }
            cal.time = sdf.parse(trigger) ?: return null
            var ms = cal.timeInMillis
            val rec = json.optString("recurrence", "none").lowercase().takeIf {
                it == "daily" || it == "weekly"
            } ?: "none"
            if (ms <= System.currentTimeMillis()) {
                // Past time: for recurring, roll to the next occurrence; one-time = reject.
                if (rec == "daily") ms += 86_400_000L
                else if (rec == "weekly") ms += 7 * 86_400_000L
                else return null
            }
            Parsed(title, ms, rec)
        } catch (_: Exception) {
            null
        }
    }

    /** Offline regex fallback for the common cases. Null = not understood. */
    fun parseOffline(text: String): Parsed? {
        val t = text.lowercase()
        val now = Calendar.getInstance(IST)
        val minRegex = Regex("""(\d+)\s*(minute|min|mint)\b""")
        val hrRegex = Regex("""(\d+)\s*(ghante|ghanta|hour|hours|hr)\b""")
        val mMin = minRegex.find(t)
        if (mMin != null) {
            val mins = mMin.groupValues[1].toIntOrNull() ?: return null
            return Parsed(text, System.currentTimeMillis() + mins * 60_000L, "none")
        }
        val mHr = hrRegex.find(t)
        if (mHr != null) {
            val hrs = mHr.groupValues[1].toIntOrNull() ?: return null
            return Parsed(text, System.currentTimeMillis() + hrs * 3_600_000L, "none")
        }
        // "kal/aaj H baje" / "tomorrow at H(am|pm)" / "today at H"
        val hmRegex = Regex("""(kal|tomorrow|aaj|today)?\s*(\d{1,2})(?::(\d{2}))?\s*(baje|am|pm)?""")
        val mHm = hmRegex.find(t)
        if (mHm != null && (mHm.groupValues[1].isNotEmpty() || mHm.groupValues[4].isNotEmpty())) {
            var hour = mHm.groupValues[2].toIntOrNull() ?: return null
            val minute = mHm.groupValues[3].toIntOrNull() ?: 0
            val ampm = mHm.groupValues[4]
            if (ampm == "pm" && hour < 12) hour += 12
            if (ampm == "am" && hour == 12) hour = 0
            if (ampm == "baje" && hour < 8) hour += 12 // "8 baje" in the evening is the common case
            val cal = Calendar.getInstance(IST).apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (mHm.groupValues[1] == "kal" || mHm.groupValues[1] == "tomorrow") {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            } else if (cal.timeInMillis <= System.currentTimeMillis()) {
                return null // ambiguous past time: ask, don't guess
            }
            return Parsed(text, cal.timeInMillis, "none")
        }
        return null
    }

    /** Parse + store as PENDING. Returns a human confirmation summary. */
    fun parseAndStage(ctx: Context, text: String): String {
        if (DostPrivacy.looksFinancial(text)) {
            return "finance se related reminder nahi laga sakta (privacy)."
        }
        val key = DostSecurePrefs.getApiKey(ctx)
        val parsed = parseWithGemini(key, text) ?: parseOffline(text)
            ?: return "samajh nahi aaya dost — time thoda saaf batao, jaise 'kal subah 9 baje' ya '20 minute me'."
        val dao = DostMemory.db(ctx).dao()
        val id = dao.insertReminder(
            DostReminder(
                text = parsed.title,
                triggerAt = parsed.triggerAt,
                recurrence = parsed.recurrence,
                requestCode = 0,
                status = "PENDING",
                ts = System.currentTimeMillis()
            )
        )
        val recTxt = when (parsed.recurrence) {
            "daily" -> ", har roz"
            "weekly" -> ", har hafte"
            else -> ""
        }
        return "Maine ye samjha: '${parsed.title}' — ${fmt(parsed.triggerAt)}$recTxt. " +
            "Confirm karne ke liye 'haan, reminder #$id lagao' bolo."
    }

    /** Confirm a staged reminder: schedules the alarm. */
    fun confirm(ctx: Context, id: Long): String {
        val dao = DostMemory.db(ctx).dao()
        val r = dao.reminderById(id) ?: return "reminder #$id nahi mila."
        if (r.status != "PENDING") return "yeh reminder pehle se ${r.status} hai."
        val code = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        DostHeartbeat.scheduleReminderAt(ctx, r.triggerAt, code, r.text)
        dao.updateReminderStatus(id, "SCHEDULED", code)
        DostMemory.db(ctx).dao().insertUndo(
            DostUndoEntry(
                action = "reminder:${r.text}",
                inverse = "cancel_reminder:$code",
                ts = System.currentTimeMillis()
            )
        )
        return "reminder lag gaya: '${r.text}' (${fmt(r.triggerAt)})."
    }

    /** Cancel a scheduled reminder by id. */
    fun cancel(ctx: Context, id: Long): String {
        val dao = DostMemory.db(ctx).dao()
        val r = dao.reminderById(id) ?: return "reminder #$id nahi mila."
        if (r.status == "SCHEDULED") DostHeartbeat.cancelReminder(ctx, r.requestCode)
        dao.cancelReminder(id)
        return "reminder cancel kar diya: '${r.text}'."
    }
}

/** ADK tools for smart reminders (agent-facing wrappers). */
class DostReminderTools(private val appContext: Context) {

    @Tool
    fun parseSmartReminder(
        @Param("natural language me reminder, jaise 'har Sunday subah 9 baje Maa ko call'") text: String
    ): String = DostSmartReminders.parseAndStage(appContext, text)

    @Tool
    fun confirmReminder(
        @Param("pending reminder ka id") id: Long
    ): String = DostSmartReminders.confirm(appContext, id)

    @Tool
    fun listReminders(): String {
        val list = DostMemory.db(appContext).dao().activeReminders()
        if (list.isEmpty()) return "koi active reminder nahi hai"
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale("en", "IN"))
            .apply { timeZone = TimeZone.getTimeZone("Asia/Kolkata") }
        return list.joinToString("\n") { r ->
            "#${r.id} ${r.text} — ${sdf.format(java.util.Date(r.triggerAt))}" +
                if (r.recurrence != "none") " (${r.recurrence})" else ""
        }
    }

    @Tool
    fun cancelReminder(
        @Param("reminder ka id") id: Long
    ): String = DostSmartReminders.cancel(appContext, id)
}

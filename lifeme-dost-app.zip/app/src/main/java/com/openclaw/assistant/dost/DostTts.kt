package com.openclaw.assistant.dost

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import org.json.JSONObject

/**
 * Pluggable TTS provider for Dost — with an honest "Meri awaaz" option.
 *
 * There is NO good free on-phone voice-cloning path, so this does NOT pretend
 * to clone anything:
 *  - SYSTEM (default, free, on-device): Android TextToSpeech, best available
 *    Hindi voice, user-pickable, pitch/rate sliders. This is Dost's voice
 *    unless the user configures ElevenLabs.
 *  - ELEVENLABS ("Meri awaaz", optional, PAID): when the user has pasted an
 *    ElevenLabs API key + Voice ID in Settings, spoken replies route through
 *    the ElevenLabs TTS API with that voice. When either is missing, or any
 *    request fails (401/402/429/network), playback falls back to System TTS
 *    silently — the chat never breaks because a voice provider failed.
 *
 * The app NEVER uploads the user's voice samples anywhere. If the user ever
 * wants his own voice, he creates the clone himself on ElevenLabs' own site
 * (their Instant Voice Cloning is a paid feature — multiple sources report
 * it is NOT on the free tier, and API access for app use is gated at Creator
 * tier) and only pastes the Voice ID + key here. Piper/Kokoro on-device TTS
 * were evaluated and NOT integrated (ONNX Runtime + phonemizer plumbing
 * cannot be verified without a device build); System TTS covers the free need.
 *
 * Streaming chat is unaffected: voice speaks the final reply text
 * (sentence-chunked), never the live token stream.
 */
object DostTts {

    const val ENGINE_SYSTEM = "system"
    const val ENGINE_ELEVENLABS = "elevenlabs"

    private const val PREFS = "dost_plain"
    private const val KEY_ENGINE = "tts_engine"
    private const val KEY_VOICE = "tts_voice_name"
    private const val KEY_PITCH = "tts_pitch"
    private const val KEY_RATE = "tts_rate"

    private val mainHandler = Handler(Looper.getMainLooper())

    // ---------- Settings ----------

    fun getEngine(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ENGINE, ENGINE_SYSTEM) ?: ENGINE_SYSTEM

    fun setEngine(ctx: Context, engine: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ENGINE, engine).apply()
    }

    /** True only when the user picked ElevenLabs AND pasted key + Voice ID. */
    fun isElevenLabsReady(ctx: Context): Boolean =
        DostSecurePrefs.getElevenLabsKey(ctx).isNotBlank() &&
            DostSecurePrefs.getElevenLabsVoiceId(ctx).isNotBlank()

    /** Effective engine: ElevenLabs when ready, otherwise System (silent fallback). */
    fun effectiveEngine(ctx: Context): String =
        if (getEngine(ctx) == ENGINE_ELEVENLABS && isElevenLabsReady(ctx)) ENGINE_ELEVENLABS
        else ENGINE_SYSTEM

    fun getVoiceName(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_VOICE, "") ?: ""

    fun setVoiceName(ctx: Context, name: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_VOICE, name).apply()
    }

    fun getPitch(ctx: Context): Float =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_PITCH, 1.0f)

    fun setPitch(ctx: Context, v: Float) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putFloat(KEY_PITCH, v.coerceIn(0.5f, 2.0f)).apply()
    }

    fun getRate(ctx: Context): Float =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_RATE, 1.0f)

    fun setRate(ctx: Context, v: Float) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putFloat(KEY_RATE, v.coerceIn(0.5f, 2.0f)).apply()
    }

    /** Persona style x user sliders, clamped to Android TTS' sane range. */
    fun effectivePitch(ctx: Context, persona: DostPersonaDef): Float =
        (persona.voicePitch * getPitch(ctx)).coerceIn(0.5f, 2.0f)

    fun effectiveRate(ctx: Context, persona: DostPersonaDef): Float =
        (persona.voiceRate * getRate(ctx)).coerceIn(0.5f, 2.0f)

    // ---------- Public speak/stop ----------

    @Volatile
    private var speakToken = 0

    /**
     * Speak a reply. [onSpeaking] fires true at start, false at end/stop.
     * ElevenLabs ignores pitch/rate (the cloned voice's own style plays);
     * System TTS applies persona x user pitch/rate.
     */
    fun speak(
        ctx: Context,
        text: String,
        persona: DostPersonaDef,
        onSpeaking: (Boolean) -> Unit
    ) {
        stop()
        if (text.isBlank()) {
            onSpeaking(false)
            return
        }
        if (effectiveEngine(ctx) == ENGINE_ELEVENLABS) {
            speakElevenLabs(ctx, text, persona, onSpeaking)
        } else {
            speakSystem(ctx, text, persona, onSpeaking)
        }
    }

    /** Stop any in-flight speech (both providers). */
    fun stop() {
        speakToken++
        try { sysTts?.stop() } catch (_: Exception) {
        }
        mainHandler.post {
            try { elPlayer?.release() } catch (_: Exception) {
            }
            elPlayer = null
            elQueue.forEach { try { it.delete() } catch (_: Exception) {
            } }
            elQueue.clear()
        }
    }

    /** Hindi voices installed on this phone (names), hi-IN first. Empty if none. */
    fun listHindiVoices(ctx: Context, onResult: (List<String>) -> Unit) {
        ensureSystem(ctx) { t ->
            val names = if (t == null) {
                emptyList()
            } else {
                try {
                    (t.voices ?: emptySet())
                        .filter { it.locale.language == "hi" }
                        .sortedWith(
                            compareBy(
                                { it.locale.toString() != "hi_IN" },
                                { it.name }
                            )
                        )
                        .map { it.name }
                } catch (_: Exception) {
                    emptyList()
                }
            }
            mainHandler.post { onResult(names) }
        }
    }

    // ---------- Sentence splitting ----------

    private fun splitSentences(text: String): List<String> {
        val parts = text.split(Regex("(?<=[.!?।])\\s+"))
            .map { it.trim() }.filter { it.isNotEmpty() }
        val out = mutableListOf<String>()
        for (p in parts) {
            var rest = p
            while (rest.length > 900) {
                out.add(rest.substring(0, 900))
                rest = rest.substring(900).trim()
            }
            if (rest.isNotEmpty()) out.add(rest)
        }
        return out
    }

    // ---------- System TTS provider ----------

    private var sysTts: TextToSpeech? = null
    private var sysReady = false
    private val sysPending = mutableListOf<(TextToSpeech?) -> Unit>()

    private fun ensureSystem(ctx: Context, cb: (TextToSpeech?) -> Unit) {
        val t = sysTts
        if (t != null && sysReady) {
            cb(t)
            return
        }
        sysPending.add(cb)
        if (t != null) return // init already in progress
        sysTts = TextToSpeech(ctx.applicationContext) { status ->
            val tt = sysTts
            if (status == TextToSpeech.SUCCESS && tt != null) {
                sysReady = true
                val pending = sysPending.toList()
                sysPending.clear()
                pending.forEach { it(tt) }
            } else {
                sysReady = false
                val pending = sysPending.toList()
                sysPending.clear()
                pending.forEach { it(null) }
            }
        }
    }

    private fun speakSystem(
        ctx: Context,
        text: String,
        persona: DostPersonaDef,
        onSpeaking: (Boolean) -> Unit
    ) {
        val token = ++speakToken
        ensureSystem(ctx) { t ->
            if (token != speakToken || t == null) {
                if (token == speakToken) onSpeaking(false)
                return@ensureSystem
            }
            try {
                val hi = t.setLanguage(Locale("hi", "IN"))
                if (hi == TextToSpeech.LANG_MISSING_DATA || hi == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale("en", "IN"))
                }
                val want = getVoiceName(ctx)
                if (want.isNotBlank()) {
                    try {
                        val v = t.voices?.firstOrNull { it.name == want }
                        if (v != null) t.voice = v
                    } catch (_: Exception) {
                    }
                }
                t.setPitch(effectivePitch(ctx, persona))
                t.setSpeechRate(effectiveRate(ctx, persona))
                val chunks = splitSentences(text)
                if (chunks.isEmpty()) {
                    onSpeaking(false)
                    return@ensureSystem
                }
                var done = 0
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        if (token == speakToken) onSpeaking(true)
                    }

                    override fun onDone(id: String?) {
                        if (token != speakToken) return
                        done++
                        if (done >= chunks.size) onSpeaking(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        if (token != speakToken) return
                        done++
                        if (done >= chunks.size) onSpeaking(false)
                    }
                })
                onSpeaking(true)
                chunks.forEachIndexed { i, chunk ->
                    t.speak(chunk, TextToSpeech.QUEUE_ADD, null, "dost-sys-$token-$i")
                }
            } catch (_: Exception) {
                onSpeaking(false)
            }
        }
    }

    // ---------- ElevenLabs provider ("Meri awaaz") ----------

    private var elPlayer: MediaPlayer? = null
    private val elQueue: ArrayDeque<File> = ArrayDeque()

    private fun elevenLabsChunk(ctx: Context, chunk: String): ByteArray? {
        val key = DostSecurePrefs.getElevenLabsKey(ctx)
        val voiceId = DostSecurePrefs.getElevenLabsVoiceId(ctx)
        if (key.isBlank() || voiceId.isBlank()) return null
        return try {
            val encodedId = URLEncoder.encode(voiceId, "UTF-8")
            val url =
                "https://api.elevenlabs.io/v1/text-to-speech/$encodedId?output_format=mp3_44100_128"
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 20000
                c.readTimeout = 90000
                c.setRequestProperty("xi-api-key", key)
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "audio/mpeg")
                val body = JSONObject()
                    .put("text", chunk)
                    .put("model_id", "eleven_multilingual_v2")
                    .put(
                        "voice_settings",
                        JSONObject().put("stability", 0.5).put("similarity_boost", 0.75)
                    )
                    .toString()
                c.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
                if (c.responseCode !in 200..299) return null
                c.inputStream.use { it.readBytes() }.takeIf { it.size > 1000 }
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun speakElevenLabs(
        ctx: Context,
        text: String,
        persona: DostPersonaDef,
        onSpeaking: (Boolean) -> Unit
    ) {
        val token = ++speakToken
        onSpeaking(true)
        Thread {
            try {
                val chunks = splitSentences(text)
                val files = mutableListOf<File>()
                var failedAt = -1
                val dir = File(ctx.cacheDir, "dost_tts").apply { mkdirs() }
                for ((i, chunk) in chunks.withIndex()) {
                    if (token != speakToken) return@Thread // stopped mid-fetch
                    val bytes = elevenLabsChunk(ctx, chunk)
                    if (bytes == null) {
                        failedAt = i
                        break
                    }
                    val out = File(dir, "el_${System.currentTimeMillis()}_$i.mp3")
                    FileOutputStream(out).use { it.write(bytes) }
                    files.add(out)
                }
                if (token != speakToken) {
                    files.forEach { try { it.delete() } catch (_: Exception) {
                    } }
                    return@Thread
                }
                if (failedAt >= 0) {
                    // Any ElevenLabs failure: silently fall back to System TTS
                    // for the remaining text (including the failed chunk).
                    files.forEach { try { it.delete() } catch (_: Exception) {
                    } }
                    val remaining = chunks.drop(failedAt).joinToString(" ")
                    if (remaining.isNotBlank()) {
                        speakSystem(ctx, remaining, persona, onSpeaking)
                    } else {
                        mainHandler.post { onSpeaking(false) }
                    }
                } else if (files.isEmpty()) {
                    mainHandler.post { onSpeaking(false) }
                } else {
                    mainHandler.post { playElQueue(files, token, onSpeaking) }
                }
            } catch (_: Exception) {
                // Last-resort fallback: System TTS for the whole reply.
                try {
                    speakSystem(ctx, text, persona, onSpeaking)
                } catch (_: Exception) {
                    mainHandler.post { onSpeaking(false) }
                }
            }
        }.start()
    }

    private fun playElQueue(files: List<File>, token: Int, onSpeaking: (Boolean) -> Unit) {
        elQueue.clear()
        elQueue.addAll(files)
        fun playNext() {
            if (token != speakToken) {
                elQueue.forEach { try { it.delete() } catch (_: Exception) {
                } }
                elQueue.clear()
                return
            }
            val f = elQueue.removeFirstOrNull()
            if (f == null) {
                onSpeaking(false)
                return
            }
            try {
                try { elPlayer?.release() } catch (_: Exception) {
                }
                val p = MediaPlayer()
                elPlayer = p
                p.setDataSource(f.absolutePath)
                p.setOnCompletionListener {
                    try { f.delete() } catch (_: Exception) {
                    }
                    playNext()
                }
                p.setOnErrorListener { _, _, _ ->
                    try { f.delete() } catch (_: Exception) {
                    }
                    playNext()
                    true
                }
                p.prepare()
                p.start()
            } catch (_: Exception) {
                try { f.delete() } catch (_: Exception) {
                }
                playNext()
            }
        }
        playNext()
    }
}

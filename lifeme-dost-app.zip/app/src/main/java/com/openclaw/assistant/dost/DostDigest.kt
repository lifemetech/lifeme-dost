package com.openclaw.assistant.dost

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.openclaw.assistant.service.OpenClawNotificationListenerService

/**
 * "While you were away" digest (Sum-Up pattern, free):
 * NotificationListenerService snapshot -> finance blocklist filter -> group by
 * app -> truncate (200 chars/message, max 20 messages) -> ONE batched Gemini
 * Flash call -> single summary. Costs one Flash call per digest, not per
 * notification.
 *
 * PRIVACY (hard): blocklisted (finance/banking/UPI) apps are dropped BEFORE
 * any processing and NEVER sent to any cloud model. Notification-listener
 * access is opt-in via system Settings with an explainer in Dost Settings.
 * The same pipeline summarises a long chat thread on demand.
 */
object DostDigest {

    private const val PREFS = "dost_plain"
    private const val KEY_ENABLED = "digest_enabled"

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, on).apply()
    }

    /** Open the system notification-listener access screen. */
    fun openListenerSettings(ctx: Context) {
        try {
            val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: Exception) {
        }
    }

    /**
     * Build one digest summary from current notifications. Returns null when
     * there is nothing (or no access / no key). Never includes blocklisted apps.
     */
    fun buildDigest(ctx: Context): String? {
        if (!isEnabled(ctx)) return null
        return try {
            val snap = DostPrivacy.filterBlocked(
                ctx,
                OpenClawNotificationListenerService.activeSnapshot()
            )
            if (snap.isEmpty()) return null
            val grouped = snap.take(20).groupBy { it.packageName }
            val sb = StringBuilder()
            for ((pkg, list) in grouped) {
                sb.append("[$pkg]\n")
                for (sbn in list.take(5)) {
                    val extras = sbn.notification?.extras
                    val title = extras?.getCharSequence("android.title")?.toString() ?: ""
                    val text = extras?.getCharSequence("android.text")?.toString() ?: ""
                    val line = "$title: ${text.take(200)}".trim()
                    if (line.isNotEmpty() && !DostPrivacy.looksFinancial(line)) {
                        sb.append("- $line\n")
                    }
                }
            }
            val material = sb.toString().trim()
            if (material.isEmpty()) return null
            val key = DostSecurePrefs.getApiKey(ctx)
            if (key.isBlank()) {
                // No key: return the raw grouped list (no cloud call at all).
                return "Notifications ka summary (bina AI ke):\n$material"
            }
            val summary = DostFallback.generateText(
                key,
                "Tum Dost ho. Neeche di gayi notifications ka ek chhota Hinglish digest banao: " +
                    "har app ke liye 1 line, sirf important cheezein. Banking/finance ka zikr mat karo.",
                material, 300, 0.3
            )
            summary?.trim()?.ifEmpty { null }
                ?: "Notifications ka summary (bina AI ke):\n$material"
        } catch (_: Exception) {
            null
        }
    }
}

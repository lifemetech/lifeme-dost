package com.openclaw.assistant.dost

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * Connectivity check for the no-network chat path.
 *
 * When offline, the chat shows a friendly Hinglish notice and does NOT call
 * the LLM (nothing is queued). All local features — Room messages, facts,
 * notes, reminders, past chats — keep working because they're on-device.
 * When the network returns, the next send automatically uses the cloud brain.
 */
object DostNet {

    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            true // fail-open: let the request try and surface its own error
        }
    }
}

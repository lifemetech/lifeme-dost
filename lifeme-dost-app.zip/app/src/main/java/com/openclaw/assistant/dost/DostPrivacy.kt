package com.openclaw.assistant.dost

import android.content.Context
import android.service.notification.StatusBarNotification

/**
 * Privacy boundary (hard requirement): the app NEVER sees money/banking/finance
 * apps. Enforcement lives here, in code:
 *
 * 1. NotificationListenerService drops notifications from blocked packages BEFORE
 *    any processing — never read, never logged, never sent to the LLM, never stored.
 * 2. The agent's tool set has no SMS/notification-content reading from blocked apps.
 * 3. Memory fact-extraction skips anything financial.
 * 4. Proactive check-ins never mention banking/finance.
 * 5. No SMS/OTP reading feature exists at all.
 *
 * The blocklist is user-editable in Dost Settings. Notification-listener access
 * itself is opt-in via system Settings.
 */
object DostPrivacy {

    /** Prefilled with common Indian finance/banking/UPI apps. User-editable. */
    private val DEFAULT_BLOCKED = linkedSetOf(
        "com.google.android.apps.nbu.paisa.user", // Google Pay
        "com.phonepe.app",                        // PhonePe
        "net.one97.paytm",                        // Paytm
        "in.org.npci.upiapp",                     // BHIM UPI
        "com.sbi.SBIFreedomPlus",                 // SBI YONO
        "com.snapwork.hdfc",                      // HDFC Bank
        "com.csam.icici.bank.imobile",            // ICICI iMobile
        "com.axis.mobile",                        // Axis Bank
        "com.kotakbank.mobile"                    // Kotak Mahindra
    )

    private const val PREFS = "dost_privacy"
    private const val KEY_BLOCKLIST = "blocked_pkgs"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The effective blocklist (user edits persist here; defaults seeded on first run). */
    fun getBlockedPackages(ctx: Context): Set<String> {
        val saved = prefs(ctx).getStringSet(KEY_BLOCKLIST, null)
        if (saved != null) return saved
        setBlockedPackages(ctx, DEFAULT_BLOCKED)
        return DEFAULT_BLOCKED
    }

    fun setBlockedPackages(ctx: Context, pkgs: Set<String>) {
        prefs(ctx).edit().putStringSet(KEY_BLOCKLIST, pkgs.toSet()).apply()
    }

    /** True when this package must never be observed. */
    fun isBlocked(ctx: Context, packageName: String?): Boolean {
        if (packageName.isNullOrEmpty()) return false
        return getBlockedPackages(ctx).contains(packageName)
    }

    /** Drop blocked packages from a notification list before any processing. */
    fun filterBlocked(
        ctx: Context,
        list: List<StatusBarNotification>
    ): List<StatusBarNotification> {
        val blocked = getBlockedPackages(ctx)
        if (blocked.isEmpty()) return list
        return list.filter { !blocked.contains(it.packageName) }
    }

    // Finance keywords — memory extraction and heartbeat skip matching text.
    private val FINANCE_WORDS = listOf(
        "bank", "upi", "paytm", "phonepe", "gpay", "google pay", "bhim",
        "bank account", "account number", "balance", "transaction",
        "otp", "debit card", "credit card", "loan", "emi", "ifsc", "kyc",
        "netbanking", "net banking", "wallet", "passbook"
    )

    /** True when text looks financial — never memorize, never proactively mention. */
    fun looksFinancial(text: String): Boolean {
        val t = text.lowercase()
        return FINANCE_WORDS.any { w -> t.contains(w) }
    }
}

package com.openclaw.assistant.dost

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Proactivity (OpenClaw heartbeat semantics, on-device):
 * 3 daily check-ins — 08:30 greeting, 14:00 check-in, 21:30 day summary.
 * Personal sideload build → exact alarms (setExactAndAllowWhileIdle).
 * Quiet hours 22:00–07:30 always respected. Max 1 notification per window.
 * PRIVACY: check-ins never mention banking/finance.
 */
object DostHeartbeat {

    // slot -> (hour, minute)
    private val SLOTS = arrayOf(8 to 30, 14 to 0, 21 to 30)

    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for ((i, slot) in SLOTS.withIndex()) {
            val (h, m) = slot
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h)
                set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val pi = PendingIntent.getBroadcast(
                ctx,
                1000 + i,
                Intent(ctx, DostCheckinReceiver::class.java).putExtra("slot", i),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            setExactCompat(am, cal.timeInMillis, pi)
        }
    }

    fun scheduleReminder(ctx: Context, minutesFromNow: Int, text: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx,
            (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            Intent(ctx, DostReminderReceiver::class.java).putExtra("text", text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExactCompat(am, System.currentTimeMillis() + minutesFromNow * 60_000L, pi)
    }

    /** Absolute-time alarm (smart reminders). The requestCode is stored in Room. */
    fun scheduleReminderAt(ctx: Context, triggerAt: Long, requestCode: Int, text: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx,
            requestCode,
            Intent(ctx, DostReminderReceiver::class.java)
                .putExtra("text", text)
                .putExtra("requestCode", requestCode),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExactCompat(am, triggerAt, pi)
    }

    /** Cancel a previously scheduled alarm by its requestCode. */
    fun cancelReminder(ctx: Context, requestCode: Int) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx,
                requestCode,
                Intent(ctx, DostReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            ) ?: return
            am.cancel(pi)
            pi.cancel()
        } catch (_: Exception) {
        }
    }

    private fun setExactCompat(am: AlarmManager, triggerAt: Long, pi: PendingIntent) {
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    /**
     * One heartbeat: cheap "should I message?" check. Returns the message or null.
     * PRIVACY: never returns anything financial.
     */
    suspend fun heartbeatCheck(ctx: Context): String? {
        val mode = DostAgent.getModelMode(ctx)
        val key = DostSecurePrefs.getApiKey(ctx)
        if (mode != "firebase" && key.isBlank()) return null

        val dao = DostMemory.db(ctx).dao()
        val facts = dao.topFacts(8).filter { !DostPrivacy.looksFinancial(it.text) }
        val history = dao.lastMessages(6).reversed()
        val convo = history.joinToString("\n") {
            (if (it.role == "user") "aadesh" else "Dost") + ": " + it.text
        }
        val factBlock = if (facts.isEmpty()) "" else
            "\nFacts:\n" + facts.joinToString("\n") { "- ${it.text}" }
        val prompt = "Tum Dost ho, aadesh ke dost. Abhi ka time dekh ke batao: kya abhi " +
            "aadesh ko ek pyaara sa proactive message bhejna chahiye (good morning / haal-chaal / " +
            "yaad dilaana / masti)? IMPORTANT: banking, finance, bank, upi, paisa, balance " +
            "ka zikr bilkul mat karo — aisa lage to seedha NO jawab do. " +
            "Sirf ek line me jawab do: 'YES: <tumhara Hinglish message, max 25 shabd>' ya 'NO'." +
            factBlock + "\nHaal ki baat:\n" + convo

        val answer = if (mode == "firebase") {
            DostAgent.heartbeatTurn(ctx, prompt)
        } else {
            DostFallback.generateText(
                key,
                "Tum Dost ho, aadesh ke dost. Sirf ek line me jawab do.",
                prompt, 120, 0.8
            )
        }?.trim() ?: return null

        if (!answer.startsWith("YES:", ignoreCase = true)) return null
        val msg = answer.substringAfter(":").trim()
        // PRIVACY: double-guard — never notify anything financial.
        if (msg.isEmpty() || DostPrivacy.looksFinancial(msg)) return null
        return msg
    }
}

class DostCheckinReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        Thread {
            try {
                runCheck(ctx, intent.getIntExtra("slot", 0))
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun runCheck(ctx: Context, slot: Int) {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val min = cal.get(Calendar.MINUTE)
        // quiet hours 22:00 - 07:30
        if (h >= 22 || h < 7 || (h == 7 && min < 30)) return

        val day = "%04d-%02d-%02d".format(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        val slotKey = "$day:$slot"
        if (DostSecurePrefs.getLastSlot(ctx) == slotKey) return // max 1 per window

        // keep the schedule alive
        DostHeartbeat.scheduleAll(ctx)

        // Morning (slot 0) and evening (slot 2) check-ins are briefings now,
        // not just "how are you?" — weather + calendar + reminders + news.
        // Other slots keep the generic proactive check.
        val briefing = when (slot) {
            0 -> DostBriefing.composeMorning(ctx)
            2 -> DostBriefing.composeEvening(ctx)
            else -> null
        }
        val msg = briefing ?: kotlinx.coroutines.runBlocking {
            DostHeartbeat.heartbeatCheck(ctx)
        } ?: return

        DostSecurePrefs.setLastSlot(ctx, slotKey)
        DostNotify.show(ctx, "Dost", msg)
    }
}

class DostBootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            DostHeartbeat.scheduleAll(ctx)
        }
    }
}

class DostReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: "Reminder"
        DostNotify.show(ctx, "Reminder", text)
        // Recurring smart reminders re-schedule themselves after firing.
        try {
            val code = intent.getIntExtra("requestCode", 0)
            if (code != 0) {
                val dao = DostMemory.db(ctx).dao()
                val r = dao.activeReminders().firstOrNull { it.requestCode == code }
                if (r != null && r.recurrence != "none") {
                    val next = when (r.recurrence) {
                        "daily" -> r.triggerAt + 86_400_000L
                        "weekly" -> r.triggerAt + 7 * 86_400_000L
                        else -> 0L
                    }
                    if (next > 0L) {
                        DostHeartbeat.scheduleReminderAt(ctx, next, code, r.text)
                        dao.rescheduleReminder(r.id, next)
                    }
                } else if (r != null) {
                    dao.updateReminderStatus(r.id, "FIRED", code)
                }
            }
        } catch (_: Exception) {
        }
    }
}

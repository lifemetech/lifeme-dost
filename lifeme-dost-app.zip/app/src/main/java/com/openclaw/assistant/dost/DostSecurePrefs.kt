package com.openclaw.assistant.dost

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Encrypted storage for the BYOK Gemini API key, plus plain prefs for flags.
 * Separate file from the fork's own SecurePrefs — no conflicts.
 */
object DostSecurePrefs {

    private fun secure(ctx: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(ctx)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            ctx,
            "dost_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun plain(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("dost_plain", Context.MODE_PRIVATE)

    fun getApiKey(ctx: Context): String = try {
        secure(ctx).getString("gemini_key", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setApiKey(ctx: Context, key: String) {
        secure(ctx).edit().putString("gemini_key", key.trim()).apply()
    }

    /** Optional: Pollinations pk_ key for image generation (user-entered). */
    fun getPollinationsKey(ctx: Context): String = try {
        secure(ctx).getString("pollinations_key", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setPollinationsKey(ctx: Context, key: String) {
        secure(ctx).edit().putString("pollinations_key", key.trim()).apply()
    }

    /** Optional: Groq API key for Whisper STT fallback (user-entered). */
    fun getGroqKey(ctx: Context): String = try {
        secure(ctx).getString("groq_key", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setGroqKey(ctx: Context, key: String) {
        secure(ctx).edit().putString("groq_key", key.trim()).apply()
    }

    /** Optional: user's own Cloudflare Worker URL for image generation. */
    fun getCfWorkerUrl(ctx: Context): String = try {
        secure(ctx).getString("cf_worker_url", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setCfWorkerUrl(ctx: Context, url: String) {
        secure(ctx).edit().putString("cf_worker_url", url.trim()).apply()
    }

    /** Optional: ElevenLabs API key for "Meri awaaz" TTS (user-entered, paid). */
    fun getElevenLabsKey(ctx: Context): String = try {
        secure(ctx).getString("elevenlabs_key", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setElevenLabsKey(ctx: Context, key: String) {
        secure(ctx).edit().putString("elevenlabs_key", key.trim()).apply()
    }

    /** Optional: ElevenLabs Voice ID for "Meri awaaz" (user-created clone). */
    fun getElevenLabsVoiceId(ctx: Context): String = try {
        secure(ctx).getString("elevenlabs_voice_id", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setElevenLabsVoiceId(ctx: Context, id: String) {
        secure(ctx).edit().putString("elevenlabs_voice_id", id.trim()).apply()
    }

    /** "yyyy-MM-dd:slot" of the last proactive notification — max 1 per window. */
    fun getLastSlot(ctx: Context): String = plain(ctx).getString("last_slot", "") ?: ""

    fun setLastSlot(ctx: Context, v: String) {
        plain(ctx).edit().putString("last_slot", v).apply()
    }
}

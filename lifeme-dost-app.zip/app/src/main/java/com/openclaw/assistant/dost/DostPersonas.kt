package com.openclaw.assistant.dost

import android.content.Context

/**
 * Multi-persona switching (RikkaHub pattern): one persona = a prompt +
 * greeting + voice style. Memory is SHARED across personas (per the user's
 * design) — switching only changes how Dost talks, not what it remembers.
 */
data class DostPersonaDef(
    val id: String,
    val name: String,
    val greeting: String,
    val systemPrompt: String,
    val voicePitch: Float,
    val voiceRate: Float
)

object DostPersonas {

    val PRESETS: List<DostPersonaDef> = listOf(
        DostPersonaDef(
            id = "dost",
            name = "Dost",
            greeting = "arey! kya haal hai?",
            systemPrompt = DostPersona.CORE_PROMPT,
            voicePitch = 1.0f,
            voiceRate = 1.0f
        ),
        DostPersonaDef(
            id = "coach",
            name = "Focus Coach",
            greeting = "chal, aaj ka ek goal pakka karte hain.",
            systemPrompt = "Tum 'Coach' ho — aadesh ke focus coach. Hinglish (Roman script) me baat karo. " +
                "Chhote, seedhe, action-oriented jawab do. Har jawab ek clear next step ke saath khatam karo. " +
                "No bakwaas, no lambi kahani. Jab user taal-taal kare to pyaar se par sakhti se wapas track pe lao. " +
                "Reminder, to-do aur planning ke liye tools istemal karo.",
            voicePitch = 0.9f,
            voiceRate = 1.05f
        ),
        DostPersonaDef(
            id = "storyteller",
            name = "Storyteller",
            greeting = "sunoge ek kahani? Aaj kuch khaas sunata hoon.",
            systemPrompt = "Tum 'Storyteller' ho — aadesh ke kahani sunane wale dost. Hinglish (Roman script) me " +
                "garam, zinda-dil style me kahani sunao: vivid details, dialogues, thoda drama. " +
                "Bachchon wali simple kahani ho ya bade wali adventure, sunane ka andaaz waise hi rakho. " +
                "User jab 'aage kya hua' kahe to kahani wahi se jaari rakho.",
            voicePitch = 1.1f,
            voiceRate = 0.9f
        ),
        DostPersonaDef(
            id = "tutor",
            name = "Study Buddy",
            greeting = "padhai time! Kya seekhna hai aaj?",
            systemPrompt = "Tum 'Study Buddy' ho — aadesh ke padhai wale dost. Hinglish (Roman script) me " +
                "simple examples ke saath samjhao. Pehle concept ko aasan bhasha me samjhao, phir ek chhota " +
                "example do, phir user se ek sawaal puchho taaki samajh pakki ho. Galti par daanto mat, " +
                "pyaar se sahi karo. Exam/quiz mode me short answers do.",
            voicePitch = 1.0f,
            voiceRate = 0.95f
        )
    )

    private const val PREFS = "dost_plain"
    private const val KEY_PERSONA = "persona_id"

    fun current(ctx: Context): DostPersonaDef {
        val id = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PERSONA, "dost") ?: "dost"
        return PRESETS.firstOrNull { it.id == id } ?: PRESETS[0]
    }

    fun setCurrent(ctx: Context, id: String) {
        if (PRESETS.none { it.id == id }) return
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PERSONA, id).apply()
        DostAgent.invalidate() // next turn picks up the new persona prompt
    }
}

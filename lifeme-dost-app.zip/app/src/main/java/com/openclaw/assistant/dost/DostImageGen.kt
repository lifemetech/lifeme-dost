package com.openclaw.assistant.dost

import android.content.Context
import com.google.adk.kt.annotations.Param
import com.google.adk.kt.annotations.Tool
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

/**
 * Image generation with a fallback chain (all free tiers, all fragile):
 *  1. Pollinations (user's pk_ key) — fast, but the free Pollen allowance is
 *     tiny now; 401 (no key) / 402 (Pollen exhausted) fall through gracefully.
 *  2. User's own Cloudflare Worker proxy (Flux-schnell, 10k Neurons/day) —
 *     URL entered in Settings; the Worker code is documented in README.
 *     The Cloudflare token NEVER lives in the app.
 *  3. AI Horde anonymous key (0000000000) — genuinely $0 but slow
 *     (~30-60 s), capped at ~580px, lowest priority. Volunteer workers can
 *     technically log prompts — never send private/personal prompts here.
 *
 * Returns the saved file path, or an error string starting with "ERROR:".
 * NEVER hardcode any key: keys come from EncryptedSharedPreferences only.
 */
object DostImageGen {

    data class Result(val path: String?, val error: String?)

    private fun downloadToFile(url: String, headers: Map<String, String>, out: File): Boolean {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 25000
                c.readTimeout = 120000
                c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                for ((k, v) in headers) c.setRequestProperty(k, v)
                if (c.responseCode !in 200..299) return false
                c.inputStream.use { input ->
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                }
                out.length() > 10_000
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun postJson(url: String, body: String, headers: Map<String, String>): Pair<Int, String> {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 25000
                c.readTimeout = 120000
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                for ((k, v) in headers) c.setRequestProperty(k, v)
                c.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
                val code = c.responseCode
                val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                    .bufferedReader().use { it.readText() }
                code to resp
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            -1 to (e.message ?: "network error")
        }
    }

    private fun httpGet(url: String, headers: Map<String, String>): Pair<Int, String> {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 25000
                c.readTimeout = 60000
                c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                for ((k, v) in headers) c.setRequestProperty(k, v)
                val code = c.responseCode
                val resp = (if (code in 200..299) c.inputStream else c.errorStream)
                    .bufferedReader().use { it.readText() }
                code to resp
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            -1 to (e.message ?: "network error")
        }
    }

    /** Generate an image. Runs the chain until one provider succeeds. */
    fun generate(ctx: Context, prompt: String): Result {
        if (prompt.isBlank()) return Result(null, "ERROR: khaali prompt")
        // Never send private prompts to the volunteer AI Horde cluster.
        val looksPrivate = DostPrivacy.looksFinancial(prompt)
        val dir = File(ctx.cacheDir, "dost_images").apply { mkdirs() }
        val out = File(dir, "img_${System.currentTimeMillis()}.png")

        // 1. Pollinations (pk_ key).
        val pk = DostSecurePrefs.getPollinationsKey(ctx)
        if (pk.isNotBlank()) {
            // Path segment: URLEncoder emits '+' for spaces, which is wrong in
            // a path — convert to %20.
            val encodedPrompt = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
            val url = "https://gen.pollinations.ai/image/" + encodedPrompt +
                "?key=" + URLEncoder.encode(pk, "UTF-8") +
                "&model=flux&width=1024&height=1024&seed=" + (System.currentTimeMillis() % 100000)
            if (downloadToFile(url, emptyMap(), out)) return Result(out.absolutePath, null)
        }

        // 2. User's Cloudflare Worker proxy (returns raw PNG bytes).
        val worker = DostSecurePrefs.getCfWorkerUrl(ctx)
        if (worker.isNotBlank()) {
            try {
                val c = URL(worker).openConnection() as HttpURLConnection
                try {
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.connectTimeout = 25000
                    c.readTimeout = 180000
                    c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    c.setRequestProperty("User-Agent", "LifeMeDost/1.0 (personal use)")
                    c.outputStream.bufferedWriter(Charsets.UTF_8).use {
                        it.write(JSONObject().put("prompt", prompt).toString())
                    }
                    if (c.responseCode in 200..299) {
                        c.inputStream.use { input ->
                            FileOutputStream(out).use { output -> input.copyTo(output) }
                        }
                        if (out.length() > 10_000) return Result(out.absolutePath, null)
                    }
                } finally {
                    c.disconnect()
                }
            } catch (_: Exception) {
            }
        }

        // 3. AI Horde anonymous (slow, small, lowest priority; never private prompts).
        if (!looksPrivate) {
            val horde = generateViaHorde(prompt, out)
            if (horde != null) return Result(horde, null)
        }

        return Result(
            null,
            "ERROR: image nahi ban payi. Pollinations key (pk_) Settings me daalo, " +
                "ya Cloudflare Worker URL set karo — dono free hain, dono ki limit hoti hai."
        )
    }

    private fun generateViaHorde(prompt: String, out: File): String? {
        return try {
            val headers = mapOf(
                "apikey" to "0000000000",
                "Client-Agent" to "LifeMeDost:1.0:personal-use"
            )
            val body = JSONObject()
                .put("prompt", prompt)
                .put(
                    "params",
                    JSONObject()
                        .put("width", 512)
                        .put("height", 512)
                        .put("steps", 25)
                )
                .toString()
            val (code, resp) = postJson("https://aihorde.net/api/v2/generate/async", body, headers)
            if (code !in 200..299) return null
            val jobId = JSONObject(resp).optString("id", "")
            if (jobId.isEmpty()) return null
            // Poll up to ~3 minutes; stop as soon as an image is ready.
            var imageUrl: String? = null
            for (i in 0 until 36) {
                Thread.sleep(5000)
                val (c2, r2) = httpGet("https://aihorde.net/api/v2/generate/status/$jobId", headers)
                if (c2 !in 200..299) continue
                val generations = JSONObject(r2).optJSONArray("generations")
                if (generations != null && generations.length() > 0) {
                    imageUrl = generations.getJSONObject(0).optString("img", "")
                    if (!imageUrl.isNullOrEmpty()) break
                }
                if (JSONObject(r2).optBoolean("faulted", false)) return null
            }
            if (imageUrl.isNullOrEmpty()) return null
            val imgFile = File(out.parentFile, "horde_${System.currentTimeMillis()}.webp")
            if (downloadToFile(imageUrl!!, emptyMap(), imgFile)) imgFile.absolutePath else null
        } catch (_: Exception) {
            null
        }
    }
}

/** ADK tool for image generation (agent-facing). */
class DostImageTools(private val appContext: Context) {

    @Tool
    fun generateImage(
        @Param("image ka prompt, English me detail me") prompt: String
    ): String {
        val result = DostImageGen.generate(appContext, prompt)
        return if (result.path != null) {
            "image ban gayi: IMAGE:${result.path} — user ko batao ki image taiyaar hai"
        } else {
            result.error ?: "image nahi ban payi"
        }
    }
}

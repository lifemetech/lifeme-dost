package com.openclaw.assistant.dost

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Google Drive backup (free): daily WorkManager job exports Dost messages+facts
 * to JSON and uploads it to the appDataFolder via the Drive REST API,
 * using an OAuth token from Google Sign-In. No Drive client library needed.
 */
object DostDriveBackup {

    const val DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val FILE_NAME = "dost-backup.json"

    @Throws(Exception::class)
    fun getToken(ctx: Context): String {
        val acct = GoogleSignIn.getLastSignedInAccount(ctx)
            ?: throw IllegalStateException("Google sign-in nahi hua")
        return GoogleAuthUtil.getToken(ctx, acct.account!!, "oauth2:$DRIVE_APPDATA_SCOPE")
    }

    fun backupNow(ctx: Context): Boolean {
        return try {
            val token = getToken(ctx)
            val dao = DostMemory.db(ctx).dao()
            val root = JSONObject()
            root.put("exportedAt", System.currentTimeMillis())
            val msgs = JSONArray()
            for (m in dao.allMessages()) {
                msgs.put(
                    JSONObject().put("role", m.role).put("text", m.text).put("ts", m.ts)
                )
            }
            val facts = JSONArray()
            for (f in dao.allFacts()) {
                // PRIVACY: financial facts are never written to the backup either.
                if (DostPrivacy.looksFinancial(f.text)) continue
                facts.put(
                    JSONObject().put("text", f.text).put("importance", f.importance).put("ts", f.ts)
                )
            }
            root.put("messages", msgs)
            root.put("facts", facts)
            val json = root.toString()
            val existingId = findFileId(token)
            if (existingId != null) updateFile(token, existingId, json) else createFile(token, json)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** May throw UserRecoverableAuthException — caller shows its resolution intent. */
    @Throws(Exception::class)
    fun restoreNow(ctx: Context): Boolean {
        val token = getToken(ctx)
        val id = findFileId(token) ?: return false
        val json = downloadFile(token, id) ?: return false
        val root = JSONObject(json)
        val dao = DostMemory.db(ctx).dao()
        dao.clearMessages()
        dao.clearFacts()
        val msgs = root.optJSONArray("messages") ?: JSONArray()
        for (i in 0 until msgs.length()) {
            val o = msgs.getJSONObject(i)
            val text = o.getString("text")
            // PRIVACY: skip financial content even in old backups.
            if (DostPrivacy.looksFinancial(text)) continue
            dao.insertMessage(
                DostMessage(role = o.getString("role"), text = text, ts = o.getLong("ts"))
            )
        }
        val facts = root.optJSONArray("facts") ?: JSONArray()
        for (i in 0 until facts.length()) {
            val o = facts.getJSONObject(i)
            val text = o.getString("text")
            if (DostPrivacy.looksFinancial(text)) continue
            dao.insertFact(
                DostFact(text = text, importance = o.getDouble("importance"), ts = o.getLong("ts"))
            )
        }
        return true
    }

    // ---------- Drive REST helpers ----------

    private fun authConn(url: String, token: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.connectTimeout = 20000
        c.readTimeout = 20000
        return c
    }

    private fun readAll(c: HttpURLConnection): String {
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return stream.bufferedReader().use { it.readText() }
    }

    private fun findFileId(token: String): String? {
        return try {
            val q = URLEncoder.encode(
                "'appDataFolder' in parents and name='$FILE_NAME' and trashed=false", "UTF-8"
            )
            val c = authConn(
                "https://www.googleapis.com/drive/v3/files?q=$q&spaces=appDataFolder&fields=files(id)",
                token, "GET"
            )
            val resp = readAll(c)
            if (c.responseCode !in 200..299) return null
            val files = JSONObject(resp).optJSONArray("files") ?: return null
            if (files.length() > 0) files.getJSONObject(0).getString("id") else null
        } catch (_: Exception) {
            null
        }
    }

    private fun createFile(token: String, json: String): Boolean {
        return try {
            val boundary = "dost${System.currentTimeMillis()}"
            val c = authConn(
                "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", token, "POST"
            )
            c.doOutput = true
            c.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
            val meta = JSONObject()
                .put("name", FILE_NAME)
                .put("parents", JSONArray().put("appDataFolder"))
                .toString()
            val body = "--$boundary\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n\r\n" +
                "$meta\r\n" +
                "--$boundary\r\n" +
                "Content-Type: application/json\r\n\r\n" +
                "$json\r\n" +
                "--$boundary--\r\n"
            OutputStreamWriter(c.outputStream, "UTF-8").use { it.write(body) }
            val resp = readAll(c)
            c.responseCode in 200..299 && resp.contains("\"id\"")
        } catch (_: Exception) {
            false
        }
    }

    private fun updateFile(token: String, id: String, json: String): Boolean {
        return try {
            val c = authConn(
                "https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media", token, "PATCH"
            )
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            OutputStreamWriter(c.outputStream, "UTF-8").use { it.write(json) }
            readAll(c)
            c.responseCode in 200..299
        } catch (_: Exception) {
            false
        }
    }

    private fun downloadFile(token: String, id: String): String? {
        return try {
            val c = authConn("https://www.googleapis.com/drive/v3/files/$id?alt=media", token, "GET")
            val resp = readAll(c)
            if (c.responseCode in 200..299) resp else null
        } catch (_: Exception) {
            null
        }
    }
}

class DostDriveBackupWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            if (GoogleSignIn.getLastSignedInAccount(applicationContext) == null) return Result.success()
            if (DostDriveBackup.backupNow(applicationContext)) Result.success() else Result.retry()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
